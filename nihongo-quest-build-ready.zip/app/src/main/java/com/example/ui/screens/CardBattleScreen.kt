package com.example.ui.screens

import androidx.activity.compose.BackHandler
import androidx.compose.animation.core.animateDpAsState
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.tween
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.interaction.collectIsHoveredAsState
import androidx.compose.foundation.interaction.collectIsPressedAsState
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.automirrored.filled.VolumeUp
import androidx.compose.material.icons.filled.AutoAwesome
import androidx.compose.material.icons.filled.Favorite
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.Shield
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.VocabularyItem
import com.example.ui.components.Gamified3DButton
import com.example.ui.components.Gamified3DCard
import com.example.ui.components.GamifiedProgressBar
import com.example.ui.state.NihongoUiState
import com.example.ui.state.NihongoViewModel
import com.example.ui.theme.GamifyBlue
import com.example.ui.theme.GamifyBlueDark
import com.example.ui.theme.GamifyBlueLight
import com.example.ui.theme.GamifyBlueShadow
import com.example.ui.theme.GamifyGreen
import com.example.ui.theme.GamifyGreenDark
import com.example.ui.theme.GamifyGreenLight
import com.example.ui.theme.GamifyGreenShadow
import com.example.ui.theme.GamifyRed
import com.example.ui.theme.GamifyRedDark
import com.example.ui.theme.GamifyRedLight
import com.example.ui.theme.GamifyRedShadow
import com.example.ui.theme.LoraFontFamily
import com.example.ui.theme.NeutralBorder
import com.example.ui.theme.NeutralCard
import com.example.ui.theme.NeutralSubtext
import com.example.ui.theme.NeutralText
import com.example.ui.theme.NeutralWhite
import com.example.ui.theme.RoundedFull
import com.example.ui.theme.RoundedLg
import com.example.ui.theme.RoundedMd
import com.example.ui.theme.RoundedSm
import com.example.util.JapaneseAudioSpeakerButton
import com.example.util.LocalJapaneseTts

@Composable
fun CardBattleScreen(
    uiState: NihongoUiState,
    viewModel: NihongoViewModel,
    modifier: Modifier = Modifier
) {
    BackHandler {
        viewModel.goBack()
    }

    val tts = LocalJapaneseTts.current
    val scrollState = rememberScrollState()
    val currentQuestion = uiState.activePveQuestion
    var aiExplanationText by remember { mutableStateOf<String?>(null) }
    var isLoadingAi by remember { mutableStateOf(false) }

    // Flash effect alpha animation: khi khớp từ, nháy màn hình nhẹ
    val flashAlpha by animateFloatAsState(
        targetValue = if (uiState.isScreenFlashing) 0.55f else 0f,
        animationSpec = tween(durationMillis = 180),
        label = "screen_flash"
    )

    Box(
        modifier = modifier
            .fillMaxSize()
            .background(NeutralWhite)
    ) {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .verticalScroll(scrollState)
                .padding(horizontal = 18.dp, vertical = 14.dp),
            verticalArrangement = Arrangement.spacedBy(14.dp)
        ) {
            // Top App Bar
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    IconButton(
                        onClick = { viewModel.goBack() },
                        modifier = Modifier
                            .size(38.dp)
                            .clip(RoundedMd)
                            .background(NeutralCard)
                            .border(1.5.dp, NeutralBorder, RoundedMd)
                            .testTag("btn_back_home_battle")
                    ) {
                        Icon(
                            imageVector = Icons.AutoMirrored.Filled.ArrowBack,
                            contentDescription = "Trang chủ",
                            tint = NeutralText
                        )
                    }
                    Text(
                        text = "CARD BATTLE (PvE)",
                        style = MaterialTheme.typography.titleMedium.copy(
                            fontWeight = FontWeight.Bold,
                            color = NeutralText
                        ),
                        modifier = Modifier.padding(start = 10.dp)
                    )
                }

                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    // Google AI Studio Button
                    IconButton(
                        onClick = {
                            isLoadingAi = true
                            viewModel.requestAiExplanationForCurrentQuestion { explanation ->
                                aiExplanationText = explanation
                                isLoadingAi = false
                            }
                        },
                        modifier = Modifier
                            .size(38.dp)
                            .clip(RoundedMd)
                            .background(GamifyBlueLight)
                            .border(1.5.dp, GamifyBlue, RoundedMd)
                            .testTag("btn_ai_studio_help")
                    ) {
                        Icon(
                            imageVector = Icons.Default.AutoAwesome,
                            contentDescription = "Google AI Studio",
                            tint = GamifyBlueDark
                        )
                    }

                    // Reset Match Button
                    IconButton(
                        onClick = { viewModel.resetPveBattle() },
                        modifier = Modifier
                            .size(38.dp)
                            .clip(RoundedMd)
                            .background(NeutralCard)
                            .border(1.5.dp, NeutralBorder, RoundedMd)
                            .testTag("btn_reset_battle")
                    ) {
                        Icon(
                            imageVector = Icons.Default.Refresh,
                            contentDescription = "Reset trận đấu",
                            tint = NeutralText
                        )
                    }
                }
            }

            // ========================================================
            // 1. PHÍA TRÊN CÙNG: THANH HP CỦA BOSS (ROUNDED-FULL BAR)
            // ========================================================
            Gamified3DCard(
                modifier = Modifier
                    .fillMaxWidth()
                    .testTag("boss_hp_card"),
                backgroundColor = Color(0xFF2C3440),
                borderColor = Color(0xFF1E232B),
                borderWidth = 2.5.dp
            ) {
                Column(
                    modifier = Modifier.padding(14.dp),
                    verticalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(6.dp)
                        ) {
                            Icon(
                                imageVector = Icons.Default.Shield,
                                contentDescription = "Boss",
                                tint = GamifyRed,
                                modifier = Modifier.size(18.dp)
                            )
                            Text(
                                text = "👹 ${uiState.bossName}",
                                style = MaterialTheme.typography.titleMedium.copy(
                                    fontWeight = FontWeight.Bold,
                                    color = Color.White,
                                    fontSize = 15.sp
                                )
                            )
                        }
                        Text(
                            text = "${uiState.bossHp} / ${uiState.maxBossHp} HP",
                            style = MaterialTheme.typography.bodyMedium.copy(
                                fontWeight = FontWeight.Bold,
                                color = Color.White
                            )
                        )
                    }

                    GamifiedProgressBar(
                        progress = uiState.bossHp.toFloat() / uiState.maxBossHp,
                        fillColor = GamifyRed,
                        trackColor = Color(0xFF404854),
                        height = 12.dp
                    )
                }
            }

            // ========================================================
            // THANH HP CỦA USER (NGƯỜI DÙNG)
            // ========================================================
            Gamified3DCard(
                modifier = Modifier
                    .fillMaxWidth()
                    .testTag("user_hp_card"),
                backgroundColor = if (uiState.isUserHit) GamifyRedLight else NeutralWhite,
                borderColor = if (uiState.isUserHit) GamifyRed else NeutralBorder,
                borderWidth = 2.dp
            ) {
                Column(
                    modifier = Modifier.padding(12.dp),
                    verticalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(6.dp)
                        ) {
                            Icon(
                                imageVector = Icons.Default.Favorite,
                                contentDescription = "User HP",
                                tint = GamifyRed,
                                modifier = Modifier.size(18.dp)
                            )
                            Text(
                                text = "NGƯỜI CHƠI (BẠN)",
                                style = MaterialTheme.typography.bodyMedium.copy(
                                    fontWeight = FontWeight.Bold,
                                    color = NeutralText
                                )
                            )
                        }
                        Text(
                            text = "${uiState.userHp} / ${uiState.maxUserHp} HP",
                            style = MaterialTheme.typography.bodyMedium.copy(
                                fontWeight = FontWeight.Bold,
                                color = GamifyRed
                            )
                        )
                    }

                    GamifiedProgressBar(
                        progress = uiState.userHp.toFloat() / uiState.maxUserHp,
                        fillColor = GamifyGreen,
                        trackColor = NeutralBorder,
                        height = 12.dp
                    )
                }
            }

            // ========================================================
            // 2. Ở GIỮA MÀN HÌNH: CÂU TIẾNG NHẬT BỊ KHUYẾT MỘT TỪ
            // ========================================================
            Gamified3DCard(
                modifier = Modifier
                    .fillMaxWidth()
                    .testTag("sentence_challenge_card"),
                backgroundColor = NeutralWhite,
                borderColor = NeutralBorder,
                borderWidth = 2.dp
            ) {
                Column(
                    modifier = Modifier.padding(18.dp),
                    verticalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Box(
                            modifier = Modifier
                                .clip(RoundedSm)
                                .background(GamifyBlueLight)
                                .border(1.dp, GamifyBlue, RoundedSm)
                                .padding(horizontal = 8.dp, vertical = 3.dp)
                        ) {
                            Text(
                                text = "THỬ THÁCH #${uiState.currentPveQuestionIndex + 1}",
                                style = MaterialTheme.typography.labelSmall.copy(
                                    color = GamifyBlueDark,
                                    fontWeight = FontWeight.Bold
                                )
                            )
                        }

                        Text(
                            text = "Lượt #${uiState.turnCount} • Điểm: ${uiState.score}",
                            style = MaterialTheme.typography.labelSmall.copy(
                                color = NeutralSubtext,
                                fontWeight = FontWeight.Bold
                            )
                        )
                    }

                    val displaySentence = if (uiState.filledBlankWord != null) {
                        currentQuestion.sentenceWithBlank.replace("＿＿＿", uiState.filledBlankWord!!)
                    } else {
                        currentQuestion.sentenceWithBlank
                    }

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = displaySentence,
                            style = MaterialTheme.typography.headlineMedium.copy(
                                color = NeutralText,
                                fontSize = 20.sp,
                                fontWeight = FontWeight.Bold,
                                lineHeight = 30.sp
                            ),
                            modifier = Modifier
                                .weight(1f)
                                .testTag("japanese_sentence_text")
                        )
                        Spacer(modifier = Modifier.width(8.dp))
                        JapaneseAudioSpeakerButton(
                            textToSpeak = displaySentence,
                            size = 40.dp,
                            iconSize = 20.dp,
                            primaryColor = GamifyBlue,
                            backgroundColor = GamifyBlueLight,
                            testTag = "btn_tts_read_battle_sentence"
                        )
                    }

                    Text(
                        text = currentQuestion.translation,
                        style = MaterialTheme.typography.bodyMedium.copy(
                            fontFamily = LoraFontFamily,
                            color = NeutralSubtext,
                            fontSize = 13.sp
                        )
                    )

                    // Phản hồi chiến đấu
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clip(RoundedMd)
                            .background(NeutralCard)
                            .padding(10.dp)
                    ) {
                        Text(
                            text = uiState.pveCombatFeedback,
                            style = MaterialTheme.typography.labelSmall.copy(
                                color = NeutralText,
                                fontWeight = FontWeight.Medium
                            )
                        )
                    }
                }
            }

            // Google AI Studio Assistance Card
            if (isLoadingAi || aiExplanationText != null) {
                Gamified3DCard(
                    modifier = Modifier.fillMaxWidth(),
                    backgroundColor = GamifyBlueLight,
                    borderColor = GamifyBlue
                ) {
                    Column(
                        modifier = Modifier.padding(14.dp),
                        verticalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(6.dp)
                        ) {
                            if (isLoadingAi) {
                                CircularProgressIndicator(
                                    color = GamifyBlue,
                                    strokeWidth = 2.dp,
                                    modifier = Modifier.size(16.dp)
                                )
                            } else {
                                Icon(
                                    imageVector = Icons.Default.AutoAwesome,
                                    contentDescription = "AI Studio",
                                    tint = GamifyBlueDark,
                                    modifier = Modifier.size(16.dp)
                                )
                            }
                            Text(
                                text = "GOOGLE AI STUDIO PHÂN TÍCH:",
                                style = MaterialTheme.typography.labelSmall.copy(
                                    fontWeight = FontWeight.Bold,
                                    color = GamifyBlueDark
                                )
                            )
                        }
                        Text(
                            text = if (isLoadingAi) "Đang phân tích cùng mô hình Gemini..." else (aiExplanationText ?: ""),
                            style = MaterialTheme.typography.bodySmall.copy(
                                fontFamily = LoraFontFamily,
                                color = NeutralText
                            )
                        )
                    }
                }
            }

            // Result Victory/Defeat Banner
            if (uiState.isVictory || uiState.isDefeat) {
                Gamified3DCard(
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("game_result_card"),
                    backgroundColor = if (uiState.isVictory) GamifyGreenLight else GamifyRedLight,
                    borderColor = if (uiState.isVictory) GamifyGreen else GamifyRed,
                    borderWidth = 3.dp
                ) {
                    Column(
                        modifier = Modifier.padding(18.dp),
                        horizontalAlignment = Alignment.CenterHorizontally,
                        verticalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        Text(
                            text = if (uiState.isVictory) "🏆 CHIẾN THẮNG! BOSS ĐÃ BỊ HẠ GỤC!" else "💀 THẤT BẠI - HẾT MÁU!",
                            style = MaterialTheme.typography.titleMedium.copy(
                                fontWeight = FontWeight.Bold,
                                color = if (uiState.isVictory) GamifyGreenDark else GamifyRedDark
                            ),
                            textAlign = TextAlign.Center
                        )
                        Text(
                            text = if (uiState.isVictory)
                                "Chúc mừng bạn đã xuất sắc giải được toàn bộ từ vựng khuyết và hạ gục Boss!"
                            else
                                "Bạn đã chọn sai từ vựng nhiều lần. Nhấn nút để thử lại!",
                            style = MaterialTheme.typography.bodySmall.copy(
                                fontFamily = LoraFontFamily,
                                color = NeutralText,
                                textAlign = TextAlign.Center
                            )
                        )
                        Gamified3DButton(
                            text = "Chơi lại trận đấu",
                            onClick = { viewModel.resetPveBattle() },
                            backgroundColor = if (uiState.isVictory) GamifyGreen else GamifyRed,
                            shadowColor = if (uiState.isVictory) GamifyGreenShadow else GamifyRedShadow,
                            modifier = Modifier.width(180.dp),
                            testTag = "btn_pve_replay"
                        )
                    }
                }
            }

            // ========================================================
            // 3. THẺ BÀI: 3-4 THẺ TỪ VỰNG 語彙(ごい)
            // - Hình chữ nhật đứng (tỉ lệ 2:3)
            // - Nền trắng, viền 3D
            // - Khi hover/press nhô lên (translate-y)
            // ========================================================
            Text(
                text = "CHỌN THẺ TỪ VỰNG ĐỂ ĐIỀN VÀO CHỖ KHUYẾT:",
                style = MaterialTheme.typography.labelSmall.copy(
                    fontWeight = FontWeight.Bold,
                    color = NeutralSubtext
                )
            )

            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(bottom = 20.dp),
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                currentQuestion.options.forEachIndexed { index, vocab ->
                    GamifiedPveCard(
                        vocabulary = vocab,
                        enabled = !uiState.isVictory && !uiState.isDefeat && uiState.filledBlankWord == null,
                        testTag = "pve_card_$index",
                        onClick = {
                            val isMatch = vocab.kanji == currentQuestion.missingWord
                            tts.speak(vocab.kanji)
                            viewModel.playPveCard(vocab)
                            if (isMatch) {
                                tts.playHitSound()
                            } else {
                                tts.playErrorSound()
                            }
                        },
                        onAudioClick = {
                            tts.speak(vocab.kanji)
                        },
                        modifier = Modifier
                            .weight(1f)
                            .padding(horizontal = 4.dp)
                    )
                }
            }
        }

        // Screen Flash animation on correct match
        if (flashAlpha > 0f) {
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .background(Color.White.copy(alpha = flashAlpha))
            )
        }
    }
}

/**
 * 3D Gamified Card for PvE
 * - 2:3 aspect ratio
 * - White background with 3D shadow
 * - Translate-y upwards on press/hover (-14.dp)
 */
@Composable
private fun GamifiedPveCard(
    vocabulary: VocabularyItem,
    enabled: Boolean,
    testTag: String,
    onClick: () -> Unit,
    modifier: Modifier = Modifier,
    onAudioClick: (() -> Unit)? = null
) {
    val interactionSource = remember { MutableInteractionSource() }
    val isHovered by interactionSource.collectIsHoveredAsState()
    val isPressed by interactionSource.collectIsPressedAsState()
    val isElevated = isHovered || isPressed

    val offsetY by animateDpAsState(
        targetValue = if (isElevated) (-14).dp else 0.dp,
        animationSpec = tween(durationMillis = 140),
        label = "card_elevation_y"
    )

    Box(
        modifier = modifier
            .aspectRatio(2f / 3f)
            .offset(y = offsetY)
            .clip(RoundedMd)
            .clickable(
                enabled = enabled,
                interactionSource = interactionSource,
                indication = null,
                onClick = onClick
            )
            .testTag(testTag)
    ) {
        // Shadow base
        Box(
            modifier = Modifier
                .fillMaxSize()
                .offset(y = 4.dp)
                .clip(RoundedMd)
                .background(Color(0xFFD6D6D6))
        )

        // Card body
        Box(
            modifier = Modifier
                .fillMaxSize()
                .clip(RoundedMd)
                .background(NeutralWhite)
                .border(2.dp, NeutralBorder, RoundedMd)
                .padding(6.dp)
        ) {
            Column(
                modifier = Modifier.fillMaxSize(),
                verticalArrangement = Arrangement.SpaceBetween,
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                // Header badge & mini audio speaker
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Box(
                        modifier = Modifier
                            .clip(RoundedSm)
                            .background(GamifyBlueLight)
                            .padding(horizontal = 4.dp, vertical = 2.dp)
                    ) {
                        Text(
                            text = "N3",
                            style = MaterialTheme.typography.labelSmall.copy(
                                fontSize = 9.sp,
                                color = GamifyBlueDark,
                                fontWeight = FontWeight.Bold
                            )
                        )
                    }

                    Box(
                        modifier = Modifier
                            .size(20.dp)
                            .clip(CircleShape)
                            .background(GamifyBlueLight)
                            .clickable { onAudioClick?.invoke() }
                            .testTag("btn_audio_${vocabulary.kanji}"),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(
                            imageVector = Icons.AutoMirrored.Filled.VolumeUp,
                            contentDescription = "Phát âm ${vocabulary.kanji}",
                            tint = GamifyBlueDark,
                            modifier = Modifier.size(12.dp)
                        )
                    }
                }

                // Center: Kanji & Hiragana
                Column(
                    horizontalAlignment = Alignment.CenterHorizontally,
                    verticalArrangement = Arrangement.Center
                ) {
                    Text(
                        text = vocabulary.hiragana,
                        style = MaterialTheme.typography.labelSmall.copy(
                            fontSize = 10.sp,
                            color = NeutralSubtext
                        )
                    )
                    Text(
                        text = vocabulary.kanji,
                        style = MaterialTheme.typography.headlineMedium.copy(
                            color = NeutralText,
                            fontSize = 20.sp,
                            fontWeight = FontWeight.Bold
                        )
                    )
                }

                // Footer: Meaning
                Text(
                    text = vocabulary.meaning.take(12),
                    style = MaterialTheme.typography.labelSmall.copy(
                        fontFamily = LoraFontFamily,
                        fontSize = 9.sp,
                        color = NeutralSubtext,
                        textAlign = TextAlign.Center
                    ),
                    maxLines = 1
                )
            }
        }
    }
}
