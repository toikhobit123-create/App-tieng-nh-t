package com.example.ui.state

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.example.data.model.BattleCard
import com.example.data.model.CardBattlePvEQuestion
import com.example.data.model.CardType
import com.example.data.model.StudyCategory
import com.example.data.model.VocabularyItem
import com.example.data.service.AiService
import com.example.data.model.QuizExercise
import com.example.data.model.QuizExerciseType
import com.example.data.model.SrsItemType
import com.example.data.model.SrsRating
import com.example.data.repository.MockDataRepository
import com.example.data.repository.QuizExerciseRepository
import com.example.data.repository.SrsRepository
import com.example.data.srs.Sm2Algorithm
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch

class NihongoViewModel : ViewModel() {

    private val _uiState = MutableStateFlow(NihongoUiState())
    val uiState: StateFlow<NihongoUiState> = _uiState.asStateFlow()

    init {
        SrsRepository.resetAllProgress()
        loadSrsSession()
        refreshSrsStats()
    }

    fun navigateTo(screen: Screen) {
        if (screen == Screen.SRS_REVIEW && _uiState.value.srsDueCards.isEmpty()) {
            loadSrsSession()
        }
        if (screen == Screen.PROFILE_STATS) {
            refreshSrsStats()
        }
        _uiState.update { it.copy(currentScreen = screen) }
    }

    fun goBack() {
        val prev = _uiState.value.previousScreen
        val curr = _uiState.value.currentScreen
        if (curr == Screen.LESSON_DETAIL) {
            _uiState.update { it.copy(currentScreen = Screen.HOME, previousScreen = Screen.HOME) }
        } else if (prev == Screen.LESSON_DETAIL) {
            _uiState.update { it.copy(currentScreen = Screen.LESSON_DETAIL, previousScreen = Screen.HOME) }
        } else {
            _uiState.update { it.copy(currentScreen = Screen.HOME, previousScreen = Screen.HOME) }
        }
    }

    /**
     * Mở màn hình Chi tiết Bài học (Lesson Detail Screen)
     */
    fun openLessonDetail(category: StudyCategory, lessonId: Int, lessonTitle: String) {
        _uiState.update {
            it.copy(
                selectedStudyCategory = category,
                selectedLessonId = lessonId,
                selectedLessonTitle = lessonTitle,
                previousScreen = Screen.HOME,
                currentScreen = Screen.LESSON_DETAIL
            )
        }
    }

    /**
     * 1. Chế độ Thẻ ghi nhớ (Flashcard / SRS) riêng cho bài học đã chọn
     */
    fun startSrsForLesson(category: StudyCategory, lessonId: Int) {
        val srsType = when (category) {
            StudyCategory.GRAMMAR -> SrsItemType.GRAMMAR
            StudyCategory.VOCABULARY -> SrsItemType.VOCABULARY
            StudyCategory.KANJI -> SrsItemType.KANJI
        }
        val allCards = SrsRepository.getAllCards()
        val lessonCards = allCards.filter { it.type == srsType && it.lessonId == lessonId }
        val cardsToStudy = if (lessonCards.isNotEmpty()) lessonCards else allCards.filter { it.type == srsType }.take(10)

        val pairs = cardsToStudy.map { card ->
            Pair(card, SrsRepository.getProgress(card.id, card.type))
        }

        _uiState.update {
            it.copy(
                srsDueCards = pairs,
                currentSrsIndex = 0,
                isSrsCardFlipped = false,
                isSessionFinished = false,
                previousScreen = Screen.LESSON_DETAIL,
                currentScreen = Screen.SRS_REVIEW
            )
        }
    }

    /**
     * 2. Chế độ Học quy nạp (Learn / Practice) với bài tập riêng của bài học
     */
    fun startPracticeForLesson(category: StudyCategory, lessonId: Int) {
        val exercises = buildExercisesForLesson(category, lessonId)
        val firstEx = exercises.firstOrNull() ?: QuizExerciseRepository.getExerciseByIndex(0)
        _uiState.update {
            it.copy(
                exerciseList = exercises,
                activeExercise = firstEx,
                currentExerciseIndex = 0,
                selectedOptionIndex = null,
                sentenceBuilderSelectedChips = emptyList(),
                sentenceBuilderAvailableChips = firstEx.builderTokens.shuffled(),
                isAnswerEvaluated = false,
                isAnswerCorrect = false,
                isShowingSimilarQuestion = false,
                aiMistakeExplanation = null,
                isAiMistakeLoading = false,
                isTestMode = false,
                previousScreen = Screen.LESSON_DETAIL,
                currentScreen = Screen.INDUCTIVE_LEARNING
            )
        }
    }

    /**
     * 3. Chế độ Kiểm tra (Test / Quiz): Bài test 10 câu đếm ngược thời gian
     */
    fun startTestForLesson(category: StudyCategory, lessonId: Int) {
        val exercises = buildExercisesForLesson(category, lessonId).take(10)
        val firstEx = exercises.firstOrNull() ?: QuizExerciseRepository.getExerciseByIndex(0)
        _uiState.update {
            it.copy(
                exerciseList = exercises,
                activeExercise = firstEx,
                currentExerciseIndex = 0,
                selectedOptionIndex = null,
                sentenceBuilderSelectedChips = emptyList(),
                sentenceBuilderAvailableChips = firstEx.builderTokens.shuffled(),
                isAnswerEvaluated = false,
                isAnswerCorrect = false,
                isShowingSimilarQuestion = false,
                aiMistakeExplanation = null,
                isAiMistakeLoading = false,
                isTestMode = true,
                testTimeRemainingSeconds = 180,
                previousScreen = Screen.LESSON_DETAIL,
                currentScreen = Screen.INDUCTIVE_LEARNING
            )
        }
    }

    /**
     * 4. Chế độ Ghép thẻ (Card Battle / Match) với từ vựng/ngữ pháp của bài học
     */
    fun startCardBattleForLesson(category: StudyCategory, lessonId: Int) {
        val questions = buildPveQuestionsForLesson(category, lessonId)
        val firstQ = questions.firstOrNull() ?: MockDataRepository.pveBattleQuestions[0]
        _uiState.update {
            it.copy(
                pveBattleQuestions = questions,
                activePveQuestion = firstQ,
                currentPveQuestionIndex = 0,
                filledBlankWord = null,
                isVictory = false,
                isDefeat = false,
                previousScreen = Screen.LESSON_DETAIL,
                currentScreen = Screen.CARD_BATTLE
            )
        }
    }

    private fun buildExercisesForLesson(category: StudyCategory, lessonId: Int): List<QuizExercise> {
        val allExercises = QuizExerciseRepository.getAllExercises()
        when (category) {
            StudyCategory.GRAMMAR -> {
                val lessonGrammar = _uiState.value.grammarPoints.filter { it.lessonId == lessonId }
                if (lessonGrammar.isNotEmpty()) {
                    val matched = allExercises.filter { ex ->
                        lessonGrammar.any { gp -> ex.grammarPoint.contains(gp.title.take(3)) || gp.title.contains(ex.grammarPoint.take(3)) }
                    }
                    if (matched.isNotEmpty()) return matched

                    return lessonGrammar.mapIndexed { idx, gp ->
                        val ex = gp.examples.firstOrNull()
                        val promptJp = ex?.jp ?: "${gp.title}を使って文を作ります。"
                        val promptVn = ex?.vn ?: gp.meaning
                        val opt = listOf(gp.title, "〜わけにはいかない", "〜べきではない", "〜恐れがある").shuffled()
                        val correctIdx = opt.indexOf(gp.title)
                        val tokens = promptJp.split(" ", "、", "。").filter { it.isNotBlank() }
                        QuizExercise(
                            id = "gen_ex_${gp.id}",
                            type = when (idx % 4) {
                                0 -> QuizExerciseType.MULTIPLE_CHOICE
                                1 -> QuizExerciseType.FILL_IN_BLANK
                                2 -> QuizExerciseType.SENTENCE_BUILDER
                                else -> QuizExerciseType.TRANSLATION
                            },
                            grammarPoint = gp.title,
                            instruction = "Chọn đáp án hoặc xếp câu chính xác cho cấu trúc ${gp.title}:",
                            promptJp = promptJp,
                            promptVn = promptVn,
                            options = opt,
                            correctAnswerIndex = correctIdx,
                            sentenceWithBlank = promptJp.replace(gp.title.take(3), "【 ＿＿＿ 】"),
                            blankMissingWord = gp.title,
                            builderTokens = tokens.shuffled(),
                            correctTokenOrder = tokens,
                            completeSentenceJp = promptJp,
                            completeSentenceVn = promptVn,
                            isJpToVn = idx % 2 == 0,
                            translationQuestion = promptJp,
                            translationOptions = listOf(promptVn, "Tôi không định làm điều đó", "Nếu có thời gian thì tôi sẽ đi", "Đã quyết định từ trước").shuffled(),
                            correctTranslationIndex = 0,
                            explanation = "【${gp.title}】${gp.meaning}. Cấu trúc: ${gp.structure}",
                            mistakeExplanation = "Hãy chú ý cấu trúc ${gp.structure} và ý nghĩa: ${gp.meaning}",
                            ruleSummary = "${gp.title}: ${gp.meaning}"
                        )
                    }
                }
            }
            StudyCategory.VOCABULARY -> {
                val lessonVocabs = _uiState.value.vocabularyList.filter { it.lessonId == lessonId }.ifEmpty {
                    _uiState.value.vocabularyList.take(10)
                }
                return lessonVocabs.mapIndexed { idx, v ->
                    val otherVocabs = _uiState.value.vocabularyList.filter { it.id != v.id }.shuffled().take(3)
                    val opts = (listOf(v.meaning) + otherVocabs.map { it.meaning }).shuffled()
                    val correctIdx = opts.indexOf(v.meaning)
                    val tokens = v.exampleSentence.ifEmpty { "${v.kanji} は 日本語 です" }.split(" ", "、", "。").filter { it.isNotBlank() }
                    QuizExercise(
                        id = "vocab_ex_${v.id}",
                        type = when (idx % 4) {
                            0 -> QuizExerciseType.MULTIPLE_CHOICE
                            1 -> QuizExerciseType.FILL_IN_BLANK
                            2 -> QuizExerciseType.SENTENCE_BUILDER
                            else -> QuizExerciseType.TRANSLATION
                        },
                        grammarPoint = "${v.kanji} (${v.hiragana})",
                        instruction = "Chọn ý nghĩa hoặc điền từ đúng cho từ vựng [${v.kanji}]:",
                        promptJp = v.exampleSentence.ifEmpty { "${v.kanji}（${v.hiragana}）" },
                        promptVn = v.meaning,
                        options = opts,
                        correctAnswerIndex = correctIdx,
                        sentenceWithBlank = v.exampleSentence.replace(v.kanji, "【 ＿＿＿ 】").ifEmpty { "【 ＿＿＿ 】（${v.hiragana}）" },
                        blankMissingWord = v.kanji,
                        builderTokens = tokens.shuffled(),
                        correctTokenOrder = tokens,
                        completeSentenceJp = v.exampleSentence,
                        completeSentenceVn = v.exampleMeaning.ifEmpty { v.meaning },
                        translationQuestion = "${v.kanji} (${v.hiragana})",
                        translationOptions = opts,
                        correctTranslationIndex = correctIdx,
                        explanation = "【${v.kanji} - ${v.hiragana}】Nghĩa: ${v.meaning}. Ví dụ: ${v.exampleSentence}",
                        mistakeExplanation = "Từ [${v.kanji}] (${v.hiragana}) có nghĩa là: ${v.meaning}",
                        ruleSummary = "${v.kanji}: ${v.meaning}"
                    )
                }
            }
            StudyCategory.KANJI -> {
                val lessonKanji = _uiState.value.kanjiList.ifEmpty { MockDataRepository.n3KanjiList }
                return lessonKanji.mapIndexed { _, k ->
                    val opts = listOf(k.meaning, "An toàn, yên tĩnh", "Bắt đầu, sơ khởi", "Khó khăn, gian khổ").shuffled()
                    QuizExercise(
                        id = "kanji_ex_${k.id}",
                        type = QuizExerciseType.MULTIPLE_CHOICE,
                        grammarPoint = "Hán tự: ${k.kanji} (${k.hanViet})",
                        instruction = "Chọn ý nghĩa chính xác của chữ Hán [${k.kanji}]:",
                        promptJp = "${k.kanji}（Hán Việt: ${k.hanViet}）\nÂm On: ${k.onyomi} • Âm Kun: ${k.kunyomi}",
                        promptVn = "Từ ghép tiêu biểu: ${k.exampleCompound} (${k.exampleCompoundMeaning})",
                        options = opts,
                        correctAnswerIndex = opts.indexOf(k.meaning),
                        explanation = "Hán tự 【${k.kanji}】 (Hán Việt: ${k.hanViet}). Nghĩa: ${k.meaning}. Ví dụ: ${k.exampleCompound} (${k.exampleCompoundMeaning})",
                        mistakeExplanation = "Chữ 【${k.kanji}】 (${k.hanViet}) mang nghĩa là: ${k.meaning}",
                        ruleSummary = "${k.kanji} [${k.hanViet}]: ${k.meaning}"
                    )
                }
            }
        }
        return allExercises
    }

    private fun buildPveQuestionsForLesson(category: StudyCategory, lessonId: Int): List<CardBattlePvEQuestion> {
        val baseVocab = when (category) {
            StudyCategory.VOCABULARY -> _uiState.value.vocabularyList.filter { it.lessonId == lessonId }.ifEmpty { MockDataRepository.initialCombatVocabList }
            else -> MockDataRepository.initialCombatVocabList
        }
        val pool = _uiState.value.vocabularyList.ifEmpty { MockDataRepository.initialCombatVocabList }
        return baseVocab.take(5).mapIndexed { idx, targetVocab ->
            val sentence = targetVocab.exampleSentence.ifEmpty { "私たちは毎日${targetVocab.kanji}を勉強します。" }
            val blanked = if (sentence.contains(targetVocab.kanji)) sentence.replace(targetVocab.kanji, "【 ＿＿＿ 】") else "【 ＿＿＿ 】（${targetVocab.hiragana}）"
            val distractors = pool.filter { it.id != targetVocab.id }.shuffled().take(3)
            val opts = (listOf(targetVocab) + distractors).shuffled()
            CardBattlePvEQuestion(
                id = "pve_lesson_${lessonId}_$idx",
                fullSentence = sentence,
                sentenceWithBlank = blanked,
                missingWord = targetVocab.kanji,
                translation = targetVocab.exampleMeaning.ifEmpty { targetVocab.meaning },
                options = opts
            )
        }
    }

    // ==========================================
    // 3 MỤC HỌC: NGỮ PHÁP, TỪ VỰNG, KANJI
    // ==========================================

    fun selectStudyCategory(category: StudyCategory) {
        _uiState.update { it.copy(selectedStudyCategory = category) }
    }

    fun selectGrammarPoint(id: String) {
        _uiState.update { it.copy(selectedGrammarPointId = id) }
    }

    fun selectKanji(id: String) {
        _uiState.update { it.copy(selectedKanjiId = id) }
    }

    fun setGrammarSearchQuery(query: String) {
        _uiState.update { it.copy(grammarSearchQuery = query) }
    }

    fun selectGrammarLesson(lessonId: Int?) {
        _uiState.update { it.copy(selectedGrammarLessonId = lessonId) }
    }

    fun selectVocabLesson(lessonId: Int?) {
        _uiState.update { it.copy(selectedVocabLessonId = lessonId) }
    }

    fun setVocabSearchQuery(query: String) {
        _uiState.update { it.copy(vocabSearchQuery = query) }
    }

    /**
     * Chuyển trực tiếp sang làm câu hỏi trắc nghiệm tương ứng với điểm ngữ pháp
     */
    fun startQuizForGrammar(grammarId: String) {
        val current = _uiState.value
        val targetIdx = current.grammarQuestions.indexOfFirst {
            it.id == grammarId || (grammarId == "np_01" && it.id == "grammar_0_koto")
        }
        val actualIdx = if (targetIdx >= 0) targetIdx else 0
        val targetQ = current.grammarQuestions[actualIdx]
        val matchingEx = current.exerciseList.find { it.grammarPoint.contains(targetQ.grammarPoint) }
            ?: QuizExerciseRepository.getExerciseByIndex(actualIdx)

        _uiState.update {
            it.copy(
                currentScreen = Screen.INDUCTIVE_LEARNING,
                currentGrammarIndex = actualIdx,
                currentExerciseIndex = actualIdx % it.exerciseList.size,
                activeQuestion = targetQ,
                activeExercise = matchingEx,
                selectedOptionIndex = null,
                sentenceBuilderSelectedChips = emptyList(),
                sentenceBuilderAvailableChips = matchingEx.builderTokens.shuffled(),
                isAnswerEvaluated = false,
                isAnswerCorrect = false,
                isShowingSimilarQuestion = false,
                aiMistakeExplanation = null,
                isAiMistakeLoading = false
            )
        }
    }

    // ==========================================
    // TÍNH NĂNG 3: CARD BATTLE (PvE) LOGIC
    // ==========================================

    /**
     * Khi click vào một thẻ bài từ vựng 語彙:
     * - Kiểm tra xem có khớp vào chỗ khuyết không
     * - Khớp: Trừ HP Boss và nháy màn hình nhẹ (flash screen)
     * - Sai: Trừ HP User
     * - Nếu HP Boss = 0: Hiện thông báo chiến thắng
     */
    fun playPveCard(vocab: VocabularyItem) {
        val current = _uiState.value
        if (current.isVictory || current.isDefeat) return

        val isMatch = vocab.kanji == current.activePveQuestion.missingWord
        val logs = current.battleCombatLog.toMutableList()

        if (isMatch) {
            // Đúng: Trừ 40-50 HP Boss, nháy màn hình nhẹ
            val damage = 40
            val newBossHp = (current.bossHp - damage).coerceAtLeast(0)
            val newScore = current.score + 100
            val isVictorious = newBossHp <= 0

            logs.add(0, "⚔️ KHỚP! Bạn đặt thẻ「${vocab.kanji}」vào câu. Trừ $damage HP của Boss!")
            if (isVictorious) {
                logs.add(0, "🏆 CHIẾN THẮNG! Boss N3 đã bị tiêu diệt hoàn toàn!")
            }

            _uiState.update {
                it.copy(
                    bossHp = newBossHp,
                    score = newScore,
                    isScreenFlashing = true,
                    filledBlankWord = vocab.kanji,
                    turnCount = it.turnCount + 1,
                    isVictory = isVictorious,
                    battleCombatLog = logs.take(8),
                    pveCombatFeedback = "Chính xác! Thẻ「${vocab.kanji}」lắp vừa khít câu tiếng Nhật."
                )
            }

            // Tắt hiệu ứng flash sau 180ms để tạo hiệu ứng chớp sáng tinh tế
            viewModelScope.launch {
                delay(180L)
                _uiState.update { it.copy(isScreenFlashing = false) }

                // Nếu chưa thắng, sau 1.5s chuyển sang câu hỏi tiếp theo
                if (!isVictorious) {
                    delay(1200L)
                    nextPveQuestion()
                }
            }
        } else {
            // Sai: Trừ 25 HP của User
            val damage = 25
            val newUserHp = (current.userHp - damage).coerceAtLeast(0)
            val isDefeated = newUserHp <= 0

            logs.add(0, "💥 KHÔNG KHỚP! Thẻ「${vocab.kanji}」chưa đúng. Boss phản đòn trừ $damage HP của bạn!")
            if (isDefeated) {
                logs.add(0, "💀 BẠN ĐÃ THẤT BẠI! Hãy ôn lại từ vựng và tái đấu.")
            }

            _uiState.update {
                it.copy(
                    userHp = newUserHp,
                    isUserHit = true,
                    turnCount = it.turnCount + 1,
                    isDefeat = isDefeated,
                    battleCombatLog = logs.take(8),
                    pveCombatFeedback = "Sai rồi! Thẻ「${vocab.kanji}」không phù hợp với ngữ cảnh câu này."
                )
            }

            // Tắt rung/chớp đỏ sau 350ms
            viewModelScope.launch {
                delay(350L)
                _uiState.update { it.copy(isUserHit = false) }
            }
        }
    }

    /**
     * Chuyển sang câu hỏi PvE kế tiếp
     */
    fun nextPveQuestion() {
        val current = _uiState.value
        val questions = current.pveBattleQuestions
        val nextIdx = (current.currentPveQuestionIndex + 1) % questions.size
        _uiState.update {
            it.copy(
                currentPveQuestionIndex = nextIdx,
                activePveQuestion = questions[nextIdx],
                filledBlankWord = null,
                pveCombatFeedback = "Câu mới xuất hiện! Hãy chọn thẻ bài thích hợp để giải quyết chỗ khuyết."
            )
        }
    }

    /**
     * Reset trận đấu Card Battle PvE
     */
    fun resetPveBattle() {
        val firstQ = _uiState.value.pveBattleQuestions[0]
        _uiState.update {
            it.copy(
                userHp = 100,
                bossHp = 150,
                turnCount = 1,
                currentPveQuestionIndex = 0,
                activePveQuestion = firstQ,
                filledBlankWord = null,
                isScreenFlashing = false,
                isUserHit = false,
                isVictory = false,
                isDefeat = false,
                pveCombatFeedback = "Trận đấu mới đã sẵn sàng! Boss N3 鬼 xuất hiện với 150 HP.",
                battleCombatLog = listOf("Trận chiến đã được thiết lập lại! Boss N3 鬼 xuất hiện với 150 HP.")
            )
        }
    }

    // ==========================================
    // HÀM TÍCH HỢP SẴN GOOGLE AI STUDIO (GEMINI API)
    // ==========================================
    fun requestAiExplanationForCurrentQuestion(onResult: (String) -> Unit) {
        val activeQ = _uiState.value.activePveQuestion
        viewModelScope.launch {
            val result = AiService.explainSentenceAndWord(
                sentence = activeQ.fullSentence,
                selectedWord = activeQ.missingWord
            )
            val explanation = result.getOrElse { "Chưa thể kết nối tới Google AI Studio: ${it.localizedMessage}" }
            onResult(explanation)
        }
    }

    /**
     * explainGrammarError: Gọi AI giải thích lỗi sai ngữ pháp cho bài tập hiện tại
     * Sử dụng model gemini-1.5-flash với system_instruction sư phạm chuyên sâu.
     */
    fun explainCurrentGrammarErrorWithAi(onResult: ((String) -> Unit)? = null) {
        val current = _uiState.value
        val ex = current.activeExercise
        val question = when (ex.type) {
            QuizExerciseType.MULTIPLE_CHOICE -> ex.promptJp
            QuizExerciseType.FILL_IN_BLANK -> ex.sentenceWithBlank
            QuizExerciseType.SENTENCE_BUILDER -> ex.completeSentenceVn
            QuizExerciseType.TRANSLATION -> ex.translationQuestion.ifEmpty { ex.promptJp }
        }

        val wrongAnswer = when (ex.type) {
            QuizExerciseType.SENTENCE_BUILDER -> {
                if (current.sentenceBuilderSelectedChips.isNotEmpty()) {
                    current.sentenceBuilderSelectedChips.joinToString("")
                } else {
                    "Chưa ghép đủ câu"
                }
            }
            else -> {
                val idx = current.selectedOptionIndex ?: 0
                ex.options.getOrElse(idx) { current.activeQuestion.options.getOrElse(idx) { "" } }
            }
        }

        val correctAnswer = when (ex.type) {
            QuizExerciseType.SENTENCE_BUILDER -> ex.correctTokenOrder.joinToString("")
            else -> ex.options.getOrElse(ex.correctAnswerIndex) { current.activeQuestion.options.getOrElse(current.activeQuestion.correctAnswerIndex) { "" } }
        }

        _uiState.update { it.copy(isAiMistakeLoading = true, aiMistakeExplanation = null) }

        viewModelScope.launch {
            val result = com.example.data.service.AiService.explainGrammarError(
                question = question,
                wrongAnswer = wrongAnswer,
                correctAnswer = correctAnswer,
                exerciseType = ex.type.title
            )
            val explanation = result.getOrElse { "Lỗi kết nối Gemini: ${it.localizedMessage}" }
            _uiState.update {
                it.copy(
                    aiMistakeExplanation = explanation,
                    isAiMistakeLoading = false
                )
            }
            onResult?.invoke(explanation)
        }
    }

    // ==========================================
    // SPACED REPETITION SYSTEM (SM-2) ACTIONS
    // ==========================================

    fun loadSrsSession(filterType: SrsItemType? = _uiState.value.selectedSrsFilter) {
        val dueCards = SrsRepository.getDueOrNewCards(filterType = filterType, limit = 12)
        _uiState.update {
            it.copy(
                srsDueCards = dueCards,
                currentSrsIndex = 0,
                isSrsCardFlipped = false,
                selectedSrsFilter = filterType,
                isWeakPointsSession = false,
                sessionTotalCount = 12.coerceAtMost(dueCards.size.coerceAtLeast(1)),
                sessionCompletedCount = 0,
                sessionCorrectCount = 0,
                isSessionFinished = false
            )
        }
    }

    /**
     * Khởi động phiên học ngắn (5-10 phút) tập trung 100% vào các ĐIỂM YẾU (Weak Points)
     */
    fun startWeakPointsReviewSession() {
        val weakCards = SrsRepository.getWeakPointsSessionCards(limit = 12)
        _uiState.update {
            it.copy(
                currentScreen = Screen.SRS_REVIEW,
                srsDueCards = weakCards,
                currentSrsIndex = 0,
                isSrsCardFlipped = false,
                isWeakPointsSession = true,
                sessionTotalCount = weakCards.size.coerceAtLeast(1),
                sessionCompletedCount = 0,
                sessionCorrectCount = 0,
                isSessionFinished = false
            )
        }
    }

    fun restartSession() {
        if (_uiState.value.isWeakPointsSession) {
            startWeakPointsReviewSession()
        } else {
            loadSrsSession()
        }
    }

    fun flipSrsCard() {
        _uiState.update { it.copy(isSrsCardFlipped = !it.isSrsCardFlipped) }
    }

    fun rateSrsCard(rating: SrsRating) {
        val current = _uiState.value
        val list = current.srsDueCards
        val idx = current.currentSrsIndex
        if (idx in list.indices) {
            val (_, progress) = list[idx]
            val updatedProgress = Sm2Algorithm.calculateNextReview(progress, rating)
            SrsRepository.saveProgress(updatedProgress)

            val isCorrect = rating != SrsRating.AGAIN
            SrsRepository.recordAnswerResult(isCorrect)

            val scoreBonus = when (rating) {
                SrsRating.EASY -> 15
                SrsRating.GOOD -> 10
                SrsRating.HARD -> 5
                SrsRating.AGAIN -> 0
            }

            val nextIdx = idx + 1
            val completed = current.sessionCompletedCount + 1
            val correctCount = current.sessionCorrectCount + (if (isCorrect) 1 else 0)
            val isFinished = nextIdx >= list.size || completed >= current.sessionTotalCount

            if (isFinished) {
                SrsRepository.completeSession()
            }

            _uiState.update {
                it.copy(
                    currentSrsIndex = nextIdx,
                    isSrsCardFlipped = false,
                    score = it.score + scoreBonus,
                    reviewedCountToday = it.reviewedCountToday + 1,
                    sessionCompletedCount = completed,
                    sessionCorrectCount = correctCount,
                    isSessionFinished = isFinished
                )
            }
            refreshSrsStats()
        }
    }

    fun selectSrsFilter(filterType: SrsItemType?) {
        loadSrsSession(filterType)
    }

    fun refreshSrsStats() {
        val stats = SrsRepository.getStatsSummary()
        _uiState.update { it.copy(srsStats = stats) }
    }

    fun resetSrsProgress() {
        SrsRepository.resetAllProgress()
        _uiState.update {
            it.copy(
                score = 0,
                turnCount = 1,
                reviewedCountToday = 0,
                sessionCompletedCount = 0,
                sessionCorrectCount = 0
            )
        }
        loadSrsSession()
        refreshSrsStats()
    }

    /**
     * Cập nhật API Key do người dùng điền trực tiếp
     */
    fun updateCustomApiKey(key: String) {
        com.example.data.service.AiService.API_KEY = key.trim()
    }

    // ==========================================
    // INDUCTIVE LEARNING: 4 DẠNG BÀI TẬP ĐA DẠNG
    // ==========================================

    fun selectGrammarOption(index: Int) {
        _uiState.update {
            it.copy(
                selectedOptionIndex = index,
                isAnswerEvaluated = false
            )
        }
    }

    /**
     * Sentence Builder (Ghép câu 3D): Khi người dùng bấm 1 thẻ từ trong kho
     */
    fun selectSentenceBuilderChip(chip: String) {
        _uiState.update { state ->
            val available = state.sentenceBuilderAvailableChips.toMutableList()
            val chipIndex = available.indexOf(chip)
            if (chipIndex >= 0) {
                available.removeAt(chipIndex)
                state.copy(
                    sentenceBuilderSelectedChips = state.sentenceBuilderSelectedChips + chip,
                    sentenceBuilderAvailableChips = available,
                    isAnswerEvaluated = false
                )
            } else {
                state
            }
        }
    }

    /**
     * Sentence Builder (Ghép câu 3D): Khi người dùng bấm bỏ 1 thẻ từ đã chọn để hoàn tác
     */
    fun removeSentenceBuilderChip(index: Int) {
        _uiState.update { state ->
            val selected = state.sentenceBuilderSelectedChips.toMutableList()
            if (index in selected.indices) {
                val chip = selected.removeAt(index)
                state.copy(
                    sentenceBuilderSelectedChips = selected,
                    sentenceBuilderAvailableChips = state.sentenceBuilderAvailableChips + chip,
                    isAnswerEvaluated = false
                )
            } else {
                state
            }
        }
    }

    fun submitGrammarAnswer() {
        val current = _uiState.value
        val ex = current.activeExercise

        val isCorrect = when (ex.type) {
            QuizExerciseType.SENTENCE_BUILDER -> {
                val userBuilt = current.sentenceBuilderSelectedChips.joinToString("")
                val targetBuilt = ex.correctTokenOrder.joinToString("")
                userBuilt.isNotEmpty() && (userBuilt == targetBuilt || current.sentenceBuilderSelectedChips == ex.correctTokenOrder)
            }
            QuizExerciseType.MULTIPLE_CHOICE,
            QuizExerciseType.FILL_IN_BLANK,
            QuizExerciseType.TRANSLATION -> {
                val selected = current.selectedOptionIndex ?: return
                selected == ex.correctAnswerIndex || selected == current.activeQuestion.correctAnswerIndex
            }
        }

        val userSummary = when (ex.type) {
            QuizExerciseType.SENTENCE_BUILDER -> current.sentenceBuilderSelectedChips.joinToString(" ")
            else -> {
                val idx = current.selectedOptionIndex ?: 0
                ex.options.getOrElse(idx) { current.activeQuestion.options.getOrElse(idx) { "" } }
            }
        }

        SrsRepository.recordAnswerResult(isCorrect)

        val completed = current.sessionCompletedCount + 1
        val correctCount = current.sessionCorrectCount + (if (isCorrect) 1 else 0)
        val isFinished = completed >= current.sessionTotalCount

        if (isFinished) {
            SrsRepository.completeSession()
        }

        val scoreBonus = if (isCorrect) 50 else 0
        _uiState.update {
            it.copy(
                isAnswerEvaluated = true,
                isAnswerCorrect = isCorrect,
                score = it.score + scoreBonus,
                userSubmittedAnswerSummary = userSummary,
                sessionCompletedCount = completed,
                sessionCorrectCount = correctCount,
                isSessionFinished = isFinished
            )
        }

        // Tự động phân tích lỗi sai qua Gemini 1.5 Flash khi làm sai
        if (!isCorrect) {
            explainCurrentGrammarErrorWithAi()
        }
    }

    fun retrySimilarQuestion() {
        val current = _uiState.value
        val ex = current.activeExercise
        val similar = ex.similarExercise
            ?: current.exerciseList.shuffled().firstOrNull { it.id != ex.id }
            ?: ex

        val correspondingQuestion = QuizExerciseRepository.toGrammarQuestion(similar)

        _uiState.update {
            it.copy(
                activeExercise = similar,
                activeQuestion = correspondingQuestion,
                selectedOptionIndex = null,
                sentenceBuilderSelectedChips = emptyList(),
                sentenceBuilderAvailableChips = similar.builderTokens.shuffled(),
                isAnswerEvaluated = false,
                isAnswerCorrect = false,
                isShowingSimilarQuestion = true,
                aiMistakeExplanation = null,
                isAiMistakeLoading = false
            )
        }
    }

    fun nextGrammarQuestion() {
        val current = _uiState.value
        val allExercises = current.exerciseList.ifEmpty { QuizExerciseRepository.getAllExercises() }
        val nextIdx = (current.currentExerciseIndex + 1) % allExercises.size
        val nextEx = allExercises[nextIdx]
        val nextQuestion = QuizExerciseRepository.toGrammarQuestion(nextEx)

        _uiState.update {
            it.copy(
                currentExerciseIndex = nextIdx,
                currentGrammarIndex = (it.currentGrammarIndex + 1) % it.grammarQuestions.size,
                activeExercise = nextEx,
                activeQuestion = nextQuestion,
                selectedOptionIndex = null,
                sentenceBuilderSelectedChips = emptyList(),
                sentenceBuilderAvailableChips = nextEx.builderTokens.shuffled(),
                isAnswerEvaluated = false,
                isAnswerCorrect = false,
                isShowingSimilarQuestion = false,
                aiMistakeExplanation = null,
                isAiMistakeLoading = false
            )
        }
    }

    fun selectVocabIndex(index: Int) {
        _uiState.update { it.copy(currentVocabIndex = index) }
    }

    fun nextVocab() {
        val current = _uiState.value
        val nextIdx = (current.currentVocabIndex + 1) % current.vocabularyList.size
        _uiState.update { it.copy(currentVocabIndex = nextIdx) }
    }

    fun prevVocab() {
        val current = _uiState.value
        val prevIdx = if (current.currentVocabIndex > 0) current.currentVocabIndex - 1 else current.vocabularyList.size - 1
        _uiState.update { it.copy(currentVocabIndex = prevIdx) }
    }
}
