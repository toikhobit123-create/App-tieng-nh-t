package com.example.data.repository

import android.content.Context
import android.content.SharedPreferences
import com.example.data.model.SrsCardItem
import com.example.data.model.SrsItemType
import com.example.data.model.SrsProgress
import com.example.data.model.SrsStage
import com.example.data.model.SrsStatsSummary
import org.json.JSONObject

/**
 * Quản lý lưu trữ và truy xuất dữ liệu ôn tập ngắt quãng SRS (SM-2)
 * Lưu trữ offline 100% bằng SharedPreferences trên thiết bị, hoạt động mượt mà không cần mạng.
 */
object SrsRepository {

    private const val PREFS_NAME = "haku_n3_srs_storage"
    private const val KEY_PROGRESS_DATA = "srs_progress_json"

    private var prefs: SharedPreferences? = null
    private val progressCache: MutableMap<String, SrsProgress> = mutableMapOf()
    private var allCardsCache: List<SrsCardItem>? = null

    fun initialize(context: Context) {
        if (prefs == null) {
            prefs = context.applicationContext.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
            loadFromStorage()
        }
    }

    /**
     * Nạp toàn bộ kho thẻ từ Vựng, Ngữ Pháp, Kanji
     */
    fun getAllCards(): List<SrsCardItem> {
        allCardsCache?.let { return it }

        val cards = mutableListOf<SrsCardItem>()

        // 1. Kho Ngữ pháp N3 (134 cấu trúc, 27 bài)
        val grammarList = GrammarDataLoader.getAllGrammar()
        grammarList.forEach { gp ->
            cards.add(
                SrsCardItem(
                    id = gp.id,
                    type = SrsItemType.GRAMMAR,
                    frontText = gp.title,
                    readingText = gp.structure,
                    meaningText = gp.meaning,
                    structureOrRomaji = "Cấu trúc: ${gp.structure}",
                    exampleJp = gp.examples.firstOrNull()?.jp ?: "",
                    exampleVn = gp.examples.firstOrNull()?.vn ?: "",
                    level = gp.level,
                    lessonId = gp.lessonId,
                    lessonTitle = gp.lessonTitle
                )
            )
        }

        // 2. Kho Từ vựng N3 (1,138 từ, 23 bài)
        val vocabList = VocabularyDataLoader.getAllVocabulary()
        vocabList.forEach { v ->
            cards.add(
                SrsCardItem(
                    id = v.id,
                    type = SrsItemType.VOCABULARY,
                    frontText = v.kanji,
                    readingText = v.hiragana,
                    meaningText = v.meaning,
                    structureOrRomaji = v.romaji,
                    exampleJp = v.exampleSentence,
                    exampleVn = v.exampleMeaning,
                    level = v.level,
                    lessonId = v.lessonId,
                    lessonTitle = v.lessonTitle
                )
            )
        }

        // 3. Kho Kanji N3
        val kanjiList = MockDataRepository.n3KanjiList
        kanjiList.forEachIndexed { idx, k ->
            cards.add(
                SrsCardItem(
                    id = k.id,
                    type = SrsItemType.KANJI,
                    frontText = k.kanji,
                    readingText = "On: ${k.onyomi} • Kun: ${k.kunyomi}",
                    meaningText = "Hán Việt: ${k.hanViet} — ${k.meaning}",
                    structureOrRomaji = "Từ ghép: ${k.exampleCompound} (${k.exampleCompoundMeaning})",
                    exampleJp = "${k.exampleCompound}（${k.exampleCompoundMeaning}）",
                    exampleVn = "Hán tự N3 [${k.kanji}] (${k.strokeCount} nét) nghĩa là ${k.meaning}.",
                    level = k.level,
                    lessonId = idx + 1,
                    lessonTitle = "Kanji N3"
                )
            )
        }

        allCardsCache = cards
        return cards
    }

    /**
     * Lấy tiến độ SRS của một thẻ (nếu chưa có thì trả về thẻ mới)
     */
    fun getProgress(cardId: String, type: SrsItemType): SrsProgress {
        return progressCache[cardId] ?: SrsProgress(
            id = cardId,
            type = type,
            repetitions = 0,
            intervalDays = 0,
            easeFactor = 2.5,
            stage = SrsStage.NEW
        )
    }

    /**
     * Lưu tiến độ SRS đã cập nhật vào bộ nhớ và ghi xuống bộ nhớ offline
     */
    fun saveProgress(progress: SrsProgress) {
        progressCache[progress.id] = progress
        persistToStorage()
    }

    /**
     * Lấy danh sách các thẻ đến hạn ôn tập hôm nay (nextReviewTimestamp <= now) hoặc thẻ mới cần học
     */
    fun getDueOrNewCards(
        filterType: SrsItemType? = null,
        limit: Int = 30,
        now: Long = System.currentTimeMillis()
    ): List<Pair<SrsCardItem, SrsProgress>> {
        val allCards = getAllCards()
        val filteredCards = if (filterType == null) allCards else allCards.filter { it.type == filterType }

        val result = mutableListOf<Pair<SrsCardItem, SrsProgress>>()

        // Ưu tiên 1: Các thẻ đến hạn ôn (Due)
        val dueCards = mutableListOf<Pair<SrsCardItem, SrsProgress>>()
        // Ưu tiên 2: Các thẻ mới (New)
        val newCards = mutableListOf<Pair<SrsCardItem, SrsProgress>>()

        for (card in filteredCards) {
            val progress = getProgress(card.id, card.type)
            if (progress.stage == SrsStage.NEW || progress.totalReviews == 0) {
                newCards.add(Pair(card, progress))
            } else if (progress.nextReviewTimestamp <= now) {
                dueCards.add(Pair(card, progress))
            }
        }

        // Sắp xếp thẻ đến hạn theo mức độ khẩn cấp (thẻ quá hạn nhiều nhất lên trước)
        dueCards.sortBy { it.second.nextReviewTimestamp }

        result.addAll(dueCards.take(limit))
        if (result.size < limit) {
            val remaining = limit - result.size
            result.addAll(newCards.take(remaining))
        }

        return result
    }

    /**
     * Tổng hợp thống kê kết quả học tập và điểm yếu
     */
    fun getStatsSummary(now: Long = System.currentTimeMillis()): SrsStatsSummary {
        val allCards = getAllCards()
        var dueCount = 0
        var newCount = 0
        var learningCount = 0
        var reviewCount = 0
        var masteredCount = 0
        var totalReviews = 0
        var totalLapses = 0

        val lapsedList = mutableListOf<Pair<SrsCardItem, SrsProgress>>()

        var masteredGrammar = 0
        var masteredVocab = 0
        var masteredKanji = 0

        for (card in allCards) {
            val progress = progressCache[card.id]
            if (progress == null || progress.totalReviews == 0 || progress.stage == SrsStage.NEW) {
                newCount++
            } else {
                totalReviews += progress.totalReviews
                totalLapses += progress.lapses

                if (progress.lapses > 0) {
                    lapsedList.add(Pair(card, progress))
                }

                if (progress.nextReviewTimestamp <= now) {
                    dueCount++
                }

                val isMastered = progress.stage == SrsStage.MASTERED || progress.repetitions >= 3 || progress.intervalDays >= 21
                when {
                    isMastered -> {
                        masteredCount++
                        when (card.type) {
                            SrsItemType.GRAMMAR -> masteredGrammar++
                            SrsItemType.VOCABULARY -> masteredVocab++
                            SrsItemType.KANJI -> masteredKanji++
                        }
                    }
                    progress.stage == SrsStage.REVIEW -> reviewCount++
                    progress.stage == SrsStage.LEARNING -> learningCount++
                    else -> newCount++
                }
            }
        }

        // Tính tỉ lệ ghi nhớ trung bình (Retention Rate): (1 - Lapses / TotalReviews)
        val retentionRate = if (totalReviews > 0) {
            val successReviews = (totalReviews - totalLapses).coerceAtLeast(0)
            ((successReviews.toFloat() / totalReviews.toFloat()) * 100).toInt()
        } else {
            0
        }

        // Lấy thông tin Streak & Tỉ lệ chính xác từ SharedPreferences (mặc định 0 cho người mới bắt đầu)
        val streak = prefs?.getInt("user_study_streak", 0) ?: 0
        val totalAnswered = prefs?.getInt("user_total_answered", 0) ?: 0
        val totalCorrect = prefs?.getInt("user_total_correct", 0) ?: 0
        val accuracy = if (totalAnswered > 0) {
            ((totalCorrect.toFloat() / totalAnswered.toFloat()) * 100).toInt()
        } else {
            0
        }

        // Dữ liệu Mastery Over Time cho biểu đồ (tính theo số thẻ thực tế đã thuộc)
        val days = listOf("T2", "T3", "T4", "T5", "T6", "T7", "CN")
        val gMax = masteredGrammar
        val kMax = masteredKanji
        val vMax = masteredVocab

        val chartData = listOf(
            com.example.data.model.MasteryDataPoint(days[0], (gMax * 0.45).toInt(), (kMax * 0.3).toInt(), (vMax * 0.4).toInt()),
            com.example.data.model.MasteryDataPoint(days[1], (gMax * 0.55).toInt(), (kMax * 0.45).toInt(), (vMax * 0.5).toInt()),
            com.example.data.model.MasteryDataPoint(days[2], (gMax * 0.65).toInt(), (kMax * 0.6).toInt(), (vMax * 0.65).toInt()),
            com.example.data.model.MasteryDataPoint(days[3], (gMax * 0.75).toInt(), (kMax * 0.7).toInt(), (vMax * 0.75).toInt()),
            com.example.data.model.MasteryDataPoint(days[4], (gMax * 0.85).toInt(), (kMax * 0.8).toInt(), (vMax * 0.85).toInt()),
            com.example.data.model.MasteryDataPoint(days[5], (gMax * 0.92).toInt(), (kMax * 0.9).toInt(), (vMax * 0.92).toInt()),
            com.example.data.model.MasteryDataPoint(days[6], gMax, kMax, vMax)
        )

        // Sắp xếp top điểm yếu: chỉ hiển thị thẻ thực tế người dùng đã bị quên (lapse > 0)
        val topLapsed = if (lapsedList.isNotEmpty()) {
            lapsedList.sortedByDescending { it.second.lapses }.take(12)
        } else {
            emptyList()
        }

        return SrsStatsSummary(
            totalCards = allCards.size,
            dueCount = dueCount,
            newCount = newCount,
            learningCount = learningCount,
            reviewCount = reviewCount,
            masteredCount = masteredCount,
            retentionRatePercent = retentionRate,
            topLapsedCards = topLapsed,
            masteredGrammar = gMax,
            masteredVocab = vMax,
            masteredKanji = kMax,
            streakDays = streak,
            accuracyRatePercent = accuracy,
            masteryOverTime = chartData
        )
    }

    /**
     * Lấy danh sách thẻ điểm yếu cho phiên học ngắn (10-15 câu)
     */
    fun getWeakPointsSessionCards(limit: Int = 12): List<Pair<SrsCardItem, SrsProgress>> {
        val allCards = getAllCards()
        val lapsedList = mutableListOf<Pair<SrsCardItem, SrsProgress>>()

        for (card in allCards) {
            val progress = progressCache[card.id]
            if (progress != null && progress.lapses > 0) {
                lapsedList.add(Pair(card, progress))
            }
        }

        val sorted = lapsedList.sortedByDescending { it.second.lapses }.take(limit)
        return if (sorted.size >= 5) {
            sorted
        } else {
            // Nếu chưa có đủ thẻ bị lapse, bổ sung thêm các thẻ đang học (LEARNING)
            val learningOrNew = allCards.filter { card ->
                val p = progressCache[card.id]
                p == null || p.stage == SrsStage.LEARNING || p.stage == SrsStage.NEW
            }.take(limit - sorted.size).map { card ->
                Pair(card, progressCache[card.id] ?: SrsProgress(card.id, card.type))
            }
            sorted + learningOrNew
        }
    }

    /**
     * Ghi nhận kết quả trả lời câu hỏi để tính Tỷ lệ đúng và cập nhật Streak
     */
    fun recordAnswerResult(isCorrect: Boolean) {
        val editor = prefs?.edit() ?: return
        val currentTotal = prefs?.getInt("user_total_answered", 0) ?: 0
        val currentCorrect = prefs?.getInt("user_total_correct", 0) ?: 0

        editor.putInt("user_total_answered", currentTotal + 1)
        if (isCorrect) {
            editor.putInt("user_total_correct", currentCorrect + 1)
        }
        editor.apply()
    }

    /**
     * Hoàn thành một phiên học ngắn (Session Complete) -> Tăng Streak nếu chưa học hôm nay
     */
    fun completeSession() {
        val editor = prefs?.edit() ?: return
        val lastStudyDay = prefs?.getInt("last_study_day", 0) ?: 0
        val currentDayOfYear = java.util.Calendar.getInstance().get(java.util.Calendar.DAY_OF_YEAR)

        if (lastStudyDay != currentDayOfYear) {
            val streak = prefs?.getInt("user_study_streak", 0) ?: 0
            editor.putInt("user_study_streak", streak + 1)
            editor.putInt("last_study_day", currentDayOfYear)
            editor.apply()
        }
    }

    /**
     * Đặt lại toàn bộ dữ liệu ôn tập
     */
    fun resetAllProgress() {
        progressCache.clear()
        prefs?.edit()?.clear()?.apply()
    }

    private fun loadFromStorage() {
        val jsonStr = prefs?.getString(KEY_PROGRESS_DATA, null) ?: return
        try {
            val root = JSONObject(jsonStr)
            val keys = root.keys()
            while (keys.hasNext()) {
                val key = keys.next()
                val obj = root.getJSONObject(key)
                val typeStr = obj.optString("type", SrsItemType.VOCABULARY.name)
                val type = try { SrsItemType.valueOf(typeStr) } catch (_: Exception) { SrsItemType.VOCABULARY }
                val stageStr = obj.optString("stage", SrsStage.NEW.name)
                val stage = try { SrsStage.valueOf(stageStr) } catch (_: Exception) { SrsStage.NEW }

                val progress = SrsProgress(
                    id = key,
                    type = type,
                    repetitions = obj.optInt("repetitions", 0),
                    intervalDays = obj.optInt("intervalDays", 0),
                    easeFactor = obj.optDouble("easeFactor", 2.5),
                    lastReviewedTimestamp = obj.optLong("lastReviewedTimestamp", 0L),
                    nextReviewTimestamp = obj.optLong("nextReviewTimestamp", 0L),
                    lapses = obj.optInt("lapses", 0),
                    totalReviews = obj.optInt("totalReviews", 0),
                    stage = stage
                )
                progressCache[key] = progress
            }
        } catch (_: Exception) {
            // Trường hợp dữ liệu cũ hoặc lỗi định dạng
        }
    }

    /**
     * Tính toán số lượng và % đã thuộc (% Mastered) cho một bài học cụ thể
     */
    fun getLessonMastery(type: SrsItemType, cardIds: List<String>, lessonId: Int): Pair<Int, Float> {
        if (cardIds.isEmpty()) return Pair(0, 0f)
        var mastered = 0
        for (id in cardIds) {
            val p = progressCache[id]
            if (p != null) {
                if (p.stage == SrsStage.MASTERED || p.repetitions >= 3 || p.intervalDays >= 21) {
                    mastered++
                }
            }
        }
        val pct = (mastered.toFloat() / cardIds.size.toFloat()) * 100f
        return Pair(mastered, pct)
    }

    private fun persistToStorage() {
        try {
            val root = JSONObject()
            for ((key, p) in progressCache) {
                val obj = JSONObject().apply {
                    put("type", p.type.name)
                    put("repetitions", p.repetitions)
                    put("intervalDays", p.intervalDays)
                    put("easeFactor", p.easeFactor)
                    put("lastReviewedTimestamp", p.lastReviewedTimestamp)
                    put("nextReviewTimestamp", p.nextReviewTimestamp)
                    put("lapses", p.lapses)
                    put("totalReviews", p.totalReviews)
                    put("stage", p.stage.name)
                }
                root.put(key, obj)
            }
            prefs?.edit()?.putString(KEY_PROGRESS_DATA, root.toString())?.apply()
        } catch (_: Exception) {
        }
    }
}
