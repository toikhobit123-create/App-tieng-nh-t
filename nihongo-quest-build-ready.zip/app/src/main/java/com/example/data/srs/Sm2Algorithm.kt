package com.example.data.srs

import com.example.data.model.SrsProgress
import com.example.data.model.SrsRating
import com.example.data.model.SrsStage
import kotlin.math.max

/**
 * Triển khai thuật toán Spaced Repetition SM-2 (SuperMemo-2)
 * Tính toán chính xác khoảng thời gian nhắc lại (Interval), số lần lặp (Repetitions) và hệ số dễ (Ease Factor).
 */
object Sm2Algorithm {

    private const val ONE_DAY_MS = 24 * 60 * 60 * 1000L

    /**
     * Tính toán lịch ôn tiếp theo khi người dùng đánh giá thẻ
     *
     * @param current Tiến độ hiện tại của thẻ
     * @param rating Đánh giá của người dùng: AGAIN, HARD, GOOD, EASY
     * @param currentTime Thời điểm hiện tại (ms)
     * @return Tiến độ mới đã cập nhật
     */
    fun calculateNextReview(
        current: SrsProgress,
        rating: SrsRating,
        currentTime: Long = System.currentTimeMillis()
    ): SrsProgress {
        val q = rating.quality
        var reps = current.repetitions
        var interval = current.intervalDays
        var ef = current.easeFactor
        var lapses = current.lapses

        when (rating) {
            SrsRating.AGAIN -> {
                // Quên (Again): Reset reps về 0, interval = 1 ngày, giảm mạnh Ease Factor (-0.20)
                reps = 0
                interval = 1
                ef = max(1.3, ef - 0.20)
                lapses += 1
            }
            SrsRating.HARD -> {
                // Khó (Hard): Tăng nhẹ interval (x1.2), giảm nhẹ EF (-0.15)
                if (reps == 0) {
                    interval = 1
                    reps = 1
                } else {
                    interval = max(1, (interval * 1.2).toInt())
                    reps += 1
                }
                ef = max(1.3, ef - 0.15)
            }
            SrsRating.GOOD -> {
                // Tốt (Good): Chuẩn SM-2 (1 ngày -> 6 ngày -> interval * EF)
                when (reps) {
                    0 -> interval = 1
                    1 -> interval = 6
                    else -> interval = max(1, (interval * ef).toInt())
                }
                reps += 1
                // Công thức điều chỉnh EF chuẩn: EF' = EF + (0.1 - (5 - q) * (0.08 + (5 - q) * 0.02))
                val delta = 0.1 - (5 - q) * (0.08 + (5 - q) * 0.02)
                ef = max(1.3, ef + delta)
            }
            SrsRating.EASY -> {
                // Dễ (Easy): Thưởng interval lớn hơn (x1.3), tăng EF (+0.15)
                when (reps) {
                    0 -> interval = 4
                    1 -> interval = 8
                    else -> interval = max(1, (interval * ef * 1.3).toInt())
                }
                reps += 1
                ef = max(1.3, ef + 0.15)
            }
        }

        val stage = when {
            interval >= 21 -> SrsStage.MASTERED
            reps >= 2 -> SrsStage.REVIEW
            reps >= 1 -> SrsStage.LEARNING
            else -> SrsStage.LEARNING
        }

        val nextReview = currentTime + (interval * ONE_DAY_MS)

        // Làm tròn Ease Factor đến 2 chữ số thập phân
        val roundedEf = (ef * 100).toInt() / 100.0

        return current.copy(
            repetitions = reps,
            intervalDays = interval,
            easeFactor = roundedEf,
            lastReviewedTimestamp = currentTime,
            nextReviewTimestamp = nextReview,
            lapses = lapses,
            totalReviews = current.totalReviews + 1,
            stage = stage
        )
    }

    /**
     * Dự đoán khoảng thời gian hiển thị trên các nút đánh giá trong UI
     */
    fun previewIntervalText(current: SrsProgress, rating: SrsRating): String {
        return when (rating) {
            SrsRating.AGAIN -> "1 ngày"
            SrsRating.HARD -> {
                if (current.repetitions == 0) "1 ngày" else "${max(1, (current.intervalDays * 1.2).toInt())} ngày"
            }
            SrsRating.GOOD -> {
                when (current.repetitions) {
                    0 -> "1 ngày"
                    1 -> "6 ngày"
                    else -> "${max(1, (current.intervalDays * current.easeFactor).toInt())} ngày"
                }
            }
            SrsRating.EASY -> {
                when (current.repetitions) {
                    0 -> "4 ngày"
                    1 -> "8 ngày"
                    else -> "${max(1, (current.intervalDays * current.easeFactor * 1.3).toInt())} ngày"
                }
            }
        }
    }
}
