package com.example.data.repository

import android.content.Context
import com.example.data.model.VocabLesson
import com.example.data.model.VocabularyItem
import java.io.InputStream

/**
 * Loads and parses JLPT N3 vocabulary lessons and words from assets or resources.
 * Contains 23 lessons and 1,138 vocabulary items.
 */
object VocabularyDataLoader {

    private var cachedLessons: List<VocabLesson>? = null
    private var cachedAllVocab: List<VocabularyItem>? = null

    fun getLessons(context: Context? = null): List<VocabLesson> {
        cachedLessons?.let { return it }
        val lessons = loadLessons(context)
        cachedLessons = lessons
        cachedAllVocab = lessons.flatMap { it.vocabList }
        return lessons
    }

    fun getAllVocabulary(context: Context? = null): List<VocabularyItem> {
        cachedAllVocab?.let { return it }
        getLessons(context)
        return cachedAllVocab ?: emptyList()
    }

    private fun loadLessons(context: Context?): List<VocabLesson> {
        val stream: InputStream? = try {
            context?.assets?.open("n3_vocabulary.json")
        } catch (_: Exception) {
            null
        } ?: try {
            VocabularyDataLoader::class.java.classLoader?.getResourceAsStream("n3_vocabulary.json")
        } catch (_: Exception) {
            null
        } ?: try {
            VocabularyDataLoader::class.java.classLoader?.getResourceAsStream("assets/n3_vocabulary.json")
        } catch (_: Exception) {
            null
        } ?: try {
            VocabularyDataLoader::class.java.getResourceAsStream("/n3_vocabulary.json")
        } catch (_: Exception) {
            null
        }

        if (stream == null) {
            return emptyList()
        }

        val text = stream.bufferedReader().use { it.readText() }
        return parseVocabularyJson(text)
    }

    fun parseVocabularyJson(text: String): List<VocabLesson> {
        val lessonBlocks = text.split(Regex("""\{\s*"lesson_id"\s*:\s*""")).drop(1)
        val lessons = mutableListOf<VocabLesson>()
        val vocabPattern = Regex("""\{\s*"word"\s*:\s*"([^"]+)"\s*,\s*"reading"\s*:\s*"([^"]+)"\s*,\s*"meaning"\s*:\s*"([^"]+)"\s*\}""")
        val lidPattern = Regex("""^(\d+)""")
        val titlePattern = Regex(""""title"\s*:\s*"([^"]+)"""")

        for ((idx, block) in lessonBlocks.withIndex()) {
            val lidMatch = lidPattern.find(block)
            val titleMatch = titlePattern.find(block)
            val lessonId = lidMatch?.groupValues?.getOrNull(1)?.toIntOrNull() ?: (idx + 1)
            val title = titleMatch?.groupValues?.getOrNull(1) ?: "Bài $lessonId"

            val wordMatches = vocabPattern.findAll(block)
            val vocabList = mutableListOf<VocabularyItem>()
            for ((wIdx, m) in wordMatches.withIndex()) {
                val word = m.groupValues[1]
                val reading = m.groupValues[2]
                val meaning = m.groupValues[3]
                vocabList.add(
                    VocabularyItem(
                        id = "vocab_${lessonId}_${wIdx + 1}",
                        kanji = word,
                        hiragana = reading,
                        romaji = reading,
                        meaning = meaning,
                        exampleSentence = "この「$word」という言葉はJLPT N3で重要です。",
                        exampleMeaning = "Từ vựng「$word」này rất quan trọng trong kỳ thi JLPT N3.",
                        level = "N3",
                        category = "語彙",
                        lessonId = lessonId,
                        lessonTitle = title
                    )
                )
            }
            lessons.add(VocabLesson(lessonId, title, vocabList))
        }
        return lessons
    }
}
