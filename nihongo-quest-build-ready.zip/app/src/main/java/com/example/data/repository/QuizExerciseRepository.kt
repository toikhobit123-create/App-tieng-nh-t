package com.example.data.repository

import com.example.data.model.GrammarQuestion
import com.example.data.model.QuizExercise
import com.example.data.model.QuizExerciseType

/**
 * QuizExerciseRepository: Kho bài tập 4 dạng đa dạng hóa cho màn hình Học Quy Nạp
 * 1. Multiple Choice: Chọn đáp án đúng từ 4 lựa chọn 3D.
 * 2. Fill-in-the-blank: Điền từ/ngữ pháp khuyết vào câu.
 * 3. Sentence Builder (Ghép câu 3D): Xếp các thẻ từ 3D theo thứ tự câu tiếng Nhật hoàn chỉnh.
 * 4. Translation (Dịch 2 chiều): Dịch Nhật sang Việt & Việt sang Nhật.
 */
object QuizExerciseRepository {

    private val exercises: List<QuizExercise> = listOf(
        // ==========================================
        // 1. MULTIPLE CHOICE (Trắc nghiệm 3D)
        // ==========================================
        QuizExercise(
            id = "quiz_mc_01",
            type = QuizExerciseType.MULTIPLE_CHOICE,
            grammarPoint = "〜ことにしています (Thói quen tự quyết định)",
            instruction = "Chọn đáp án đúng nhất để hoàn thành thói quen bản thân tự duy trì:",
            promptJp = "健康のために、毎日野菜を＿＿＿ことにしています。",
            promptVn = "Vì sức khỏe, tôi duy trì thói quen ăn rau mỗi ngày.",
            options = listOf("食べる", "食べた", "食べよう", "食べて"),
            correctAnswerIndex = 0,
            explanation = "【〜ことにしています】Cấu trúc: V-る / V-ない + ことにしている. Biểu thị thói quen do chính bản thân tự quyết định và đang duy trì đều đặn.",
            mistakeExplanation = "Sai ngữ pháp: Cấu trúc này bắt buộc đi với động từ thể từ điển (V-る) hoặc phủ định (V-ない). Các dạng quá khứ (た), ý chí (よう) hay thể て không kết hợp với ことにしている.",
            ruleSummary = "QUY LUẬT QUY NẠP: V-る / V-ない + ことにしている\n→ Thói quen do chính bản thân chủ động quyết định và duy trì."
        ),

        // ==========================================
        // 2. FILL-IN-THE-BLANK (Điền từ khuyết)
        // ==========================================
        QuizExercise(
            id = "quiz_fib_01",
            type = QuizExerciseType.FILL_IN_BLANK,
            grammarPoint = "～どんなに…ても (Dù có... đến mức nào chăng nữa)",
            instruction = "Chọn từ/đuôi liên kết nhượng bộ thích hợp để điền vào chỗ khuyết:",
            promptJp = "どんなに道が険しく【 ＿＿＿ 】、私たちは目標に向かって進み続ける。",
            promptVn = "Dù cho con đường có hiểm trở thế nào, chúng tôi vẫn kiên định tiến bước.",
            sentenceWithBlank = "どんなに道が険しく【 ＿＿＿ 】、私たちは目標に向かって進み続ける。",
            blankMissingWord = "ても",
            options = listOf("ても", "たら", "なら", "ば"),
            correctAnswerIndex = 0,
            explanation = "【どんなに…ても】Đi với dạng Te-mo mang nghĩa nhượng bộ cao: 'Dù cho con đường có hiểm trở thế nào, chúng tôi vẫn kiên định tiến bước'.",
            mistakeExplanation = "Phó từ 'どんなに' (dù có thế nào) bắt buộc phải cặp đôi với đuôi nhượng bộ '～ても / ～でも'. Các dạng giả định たら, なら, ば không tương thích ngữ nghĩa.",
            ruleSummary = "QUY LUẬT QUY NẠP: どんなに + [Tính từ đuôi い → くても / Động từ → ても]\n→ Dù mức độ của vế trước có cao đến mấy, thực tế ở vế sau vẫn không lay chuyển."
        ),

        // ==========================================
        // 3. SENTENCE BUILDER (Ghép câu 3D)
        // ==========================================
        QuizExercise(
            id = "quiz_sb_01",
            type = QuizExerciseType.SENTENCE_BUILDER,
            grammarPoint = "～にしたがって (Theo như / Cùng với)",
            instruction = "Chạm vào các thẻ từ 3D theo thứ tự để xếp thành câu tiếng Nhật hoàn chỉnh:",
            promptJp = "Cùng với việc dần quen cuộc sống ở Nhật, tiếng Nhật cũng nói tự nhiên hơn.",
            promptVn = "Cùng với việc dần quen cuộc sống ở Nhật, tiếng Nhật cũng nói tự nhiên hơn.",
            completeSentenceJp = "日本での生活に慣れるにしたがって、日本語も自然に話せるようになった。",
            completeSentenceVn = "Cùng với việc dần quen cuộc sống ở Nhật, tiếng Nhật cũng nói tự nhiên hơn.",
            builderTokens = listOf(
                "生活に",
                "日本での",
                "日本語も",
                "慣れるにしたがって、",
                "話せるようになった",
                "自然に"
            ),
            correctTokenOrder = listOf(
                "日本での",
                "生活に",
                "慣れるにしたがって、",
                "日本語も",
                "自然に",
                "話せるようになった"
            ),
            explanation = "【にしたがって】Diễn đạt quá trình biến đổi liên tục kéo theo kết quả: 'Cùng với việc dần quen cuộc sống ở Nhật, tiếng Nhật cũng nói tự nhiên hơn'.",
            mistakeExplanation = "Trật tự câu tiếng Nhật tiêu chuẩn: Thành phần bối cảnh (日本での生活に) + Vế biến đổi cùng ngữ pháp (慣れるにしたがって、) + Kết quả theo sau (日本語も自然に話せるようになった).",
            ruleSummary = "QUY LUẬT QUY NẠP: [V-る / N] + にしたがって\n→ Diễn tả sự biến đổi kéo theo theo thời gian: Cùng với tiến trình của vế trước thì vế sau cũng dần thay đổi."
        ),

        // ==========================================
        // 4. TRANSLATION (Dịch 2 chiều: Nhật -> Việt)
        // ==========================================
        QuizExercise(
            id = "quiz_trans_01",
            type = QuizExerciseType.TRANSLATION,
            grammarPoint = "～につれて (Càng... thì càng...)",
            instruction = "Dịch câu tiếng Nhật sau sang tiếng Việt chuẩn xác nhất về sắc thái N3:",
            isJpToVn = true,
            promptJp = "台風が近づくにつれて、雨と風がどんどん強くなってきた。",
            promptVn = "Dịch nghĩa đúng cấu trúc tỉ lệ thuận ～につれて:",
            translationQuestion = "台風が近づくにつれて、雨と風がどんどん強くなってきた。",
            translationOptions = listOf(
                "Khi bão càng tiến đến gần, mưa gió càng trở nên dữ dội.",
                "Vì cơn bão đã tan nên mưa gió bắt đầu tạnh dần.",
                "Chỉ riêng lúc có bão thì mưa gió mới bất ngờ xuất hiện.",
                "Đối với cơn bão, mưa gió không có ảnh hưởng gì lớn."
            ),
            options = listOf(
                "Khi bão càng tiến đến gần, mưa gió càng trở nên dữ dội.",
                "Vì cơn bão đã tan nên mưa gió bắt đầu tạnh dần.",
                "Chỉ riêng lúc có bão thì mưa gió mới bất ngờ xuất hiện.",
                "Đối với cơn bão, mưa gió không có ảnh hưởng gì lớn."
            ),
            correctAnswerIndex = 0,
            correctTranslationIndex = 0,
            explanation = "【につれて】Diễn tả hai sự việc cùng biến đổi tỉ lệ thuận với nhau: 'Khi bão càng tiến đến gần, mưa gió càng trở nên dữ dội'.",
            mistakeExplanation = "Cần phân biệt rõ: ～につれて biểu thị hai sự biến đổi song hành cùng chiều (càng A thì càng B). Các phương án khác biểu thị nguyên nhân đơn thuần hoặc sự việc trớ trêu, không đúng nghĩa tỉ lệ thuận.",
            ruleSummary = "QUY LUẬT QUY NẠP: [V-る / N] + につれて\n→ Diễn đạt sự biến đổi tỉ lệ thuận song hành tự nhiên giữa hai vế."
        ),

        // ==========================================
        // 5. FILL-IN-THE-BLANK (Điền từ khuyết)
        // ==========================================
        QuizExercise(
            id = "quiz_fib_02",
            type = QuizExerciseType.FILL_IN_BLANK,
            grammarPoint = "〜にかぎって (Chỉ riêng / Đúng vào lúc)",
            instruction = "Chọn từ biểu thị sự trớ trêu, không may vào chỗ trống:",
            promptJp = "傘を持っていない日【 ＿＿＿ 】、決まって雨が降るものだ。",
            promptVn = "Đúng vào cái ngày không mang ô thì y như rằng trời đổ mưa.",
            sentenceWithBlank = "傘を持っていない日【 ＿＿＿ 】、決まって雨が降るものだ。",
            blankMissingWord = "に限って",
            options = listOf("に限って", "を通して", "を通じて", "について"),
            correctAnswerIndex = 0,
            explanation = "【に限って (にかぎって)】Diễn tả sự trớ trêu, xui xẻo: 'Đúng vào cái ngày không mang ô thì y như rằng trời đổ mưa'.",
            mistakeExplanation = "Sai cấu trúc: 'を通して / を通じて' mang nghĩa thông qua hoặc suốt khoảng thời gian, còn 'について' là về vấn đề gì đó. Để nói về sự trớ trêu đúng lúc cần dùng に限って.",
            ruleSummary = "QUY LUẬT QUY NẠP: N + に限って\n→ Nhấn mạnh trường hợp ngoại lệ trớ trêu, không may: Đúng vào lúc đặc biệt đó thì sự việc bất như ý lại xảy ra."
        ),

        // ==========================================
        // 6. TRANSLATION (Dịch 2 chiều: Việt -> Nhật)
        // ==========================================
        QuizExercise(
            id = "quiz_trans_02",
            type = QuizExerciseType.TRANSLATION,
            grammarPoint = "〜わけにはいかない (Không thể vì trách nhiệm/lương tâm)",
            instruction = "Dịch câu tiếng Việt sau sang tiếng Nhật đúng cấu trúc trách nhiệm N3:",
            isJpToVn = false,
            promptJp = "Dịch câu sang tiếng Nhật:",
            promptVn = "Ngày mai có kỳ thi JLPT quan trọng nên đêm nay tôi không thể thức khuya được.",
            translationQuestion = "Ngày mai có kỳ thi JLPT quan trọng nên đêm nay tôi không thể thức khuya được.",
            translationOptions = listOf(
                "明日は大事なJLPT試験があるので、今夜夜更かしするわけにはいかない。",
                "明日は大事なJLPT試験があるので、今夜夜更かしするわけがない。",
                "明日は大事なJLPT試験があるので、今夜夜更かしするわけではない。",
                "明日は大事なJLPT試験があるので、今夜夜更かしするはずがない。"
            ),
            options = listOf(
                "明日は大事なJLPT試験があるので、今夜夜更かしするわけにはいかない。",
                "明日は大事なJLPT試験があるので、今夜夜更かしするわけがない。",
                "明日は大事なJLPT試験があるので、今夜夜更かしするわけではない。",
                "明日は大事なJLPT試験があるので、今夜夜更かしするはずがない。"
            ),
            correctAnswerIndex = 0,
            correctTranslationIndex = 0,
            explanation = "【〜わけにはいかない】Biểu thị: vì lương tâm, trách nhiệm, đạo đức hoặc hoàn cảnh bắt buộc mà không thể làm một việc gì đó.",
            mistakeExplanation = "Sắc thái khác biệt: 'わけがない' là phán đoán logic (tuyệt đối không thể nào), 'わけではない' là phủ định một phần (không hẳn là), còn 'わけにはいかない' mới là không thể làm vì bổn phận và trách nhiệm của bản thân.",
            ruleSummary = "QUY LUẬT QUY NẠP: V-る + わけにはいかない\n→ Không thể làm một việc gì đó vì định kiến xã hội, trách nhiệm, lương tâm hoặc hoàn cảnh bắt buộc."
        ),

        // ==========================================
        // 7. SENTENCE BUILDER (Ghép câu 3D)
        // ==========================================
        QuizExercise(
            id = "quiz_sb_02",
            type = QuizExerciseType.SENTENCE_BUILDER,
            grammarPoint = "〜ことにしている (Thói quen tự quyết định)",
            instruction = "Xếp các khối từ 3D theo thứ tự câu diễn tả thói quen đọc sách mỗi tối:",
            promptJp = "Cho dù bận rộn đến mấy, tôi vẫn duy trì thói quen đọc sách trước khi ngủ.",
            promptVn = "Cho dù bận rộn đến mấy, tôi vẫn duy trì thói quen đọc sách trước khi ngủ.",
            completeSentenceJp = "どんなに忙しくても、寝る前に本を読むことにしている。",
            completeSentenceVn = "Cho dù bận rộn đến mấy, tôi vẫn duy trì thói quen đọc sách trước khi ngủ.",
            builderTokens = listOf(
                "寝る前に",
                "本を読む",
                "どんなに忙しくても、",
                "ことにしている"
            ),
            correctTokenOrder = listOf(
                "どんなに忙しくても、",
                "寝る前に",
                "本を読む",
                "ことにしている"
            ),
            explanation = "Cấu trúc: どんなに...ても (nhượng bộ) + 寝る前に (thời điểm) + V-る + ことにしている (thói quen tự duy trì).",
            mistakeExplanation = "Thứ tự câu: Vế nhượng bộ đứng đầu câu (どんなに忙しくても、) -> Bối cảnh thời gian (寝る前に) -> Hành động duy trì thói quen (本を読むことにしている).",
            ruleSummary = "QUY LUẬT QUY NẠP: どんなに...ても + V-る + ことにしている\n→ Dù điều kiện bên ngoài thế nào thì thói quen do bản thân chủ động đặt ra vẫn được thực hiện."
        ),

        // ==========================================
        // 8. MULTIPLE CHOICE (Trắc nghiệm 3D)
        // ==========================================
        QuizExercise(
            id = "quiz_mc_02",
            type = QuizExerciseType.MULTIPLE_CHOICE,
            grammarPoint = "〜から〜にかけて (Từ khoảng... đến khoảng...)",
            instruction = "Chọn từ biểu thị khoảng thời gian liên tục đại khái:",
            promptJp = "今夜から明日の朝＿＿＿、強い雨が降る恐れがあります。",
            promptVn = "Từ đêm nay đến khoảng sáng mai, có nguy cơ mưa to.",
            options = listOf("にかけて", "について", "にとって", "に対して"),
            correctAnswerIndex = 0,
            explanation = "【〜から〜にかけて】Biểu thị một khoảng thời gian hoặc không gian đại khái từ mốc A đến mốc B (ranh giới không rạch ròi).",
            mistakeExplanation = "Sai ngữ nghĩa: 'について' là về vấn đề, 'にとって' là đối với (lập trường), 'に対して' là đối với/hướng tới. Để chỉ khoảng đại khái thời tiết cần dùng にかけて.",
            ruleSummary = "QUY LUẬT QUY NẠP: N1 から N2 にかけて\n→ Từ khoảng thời gian/không gian A đến B (diễn biến kéo dài liên tục, không rõ ranh giới kết thúc)."
        )
    )

    fun getAllExercises(): List<QuizExercise> = exercises

    fun getExerciseByIndex(index: Int): QuizExercise {
        return exercises[index.coerceIn(0, exercises.lastIndex)]
    }

    /**
     * Chuyển đổi QuizExercise sang GrammarQuestion để tương thích ngược hoàn hảo với ViewModel và Unit Test
     */
    fun toGrammarQuestion(exercise: QuizExercise): GrammarQuestion {
        val questionText = when (exercise.type) {
            QuizExerciseType.MULTIPLE_CHOICE -> exercise.promptJp
            QuizExerciseType.FILL_IN_BLANK -> exercise.sentenceWithBlank
            QuizExerciseType.SENTENCE_BUILDER -> exercise.completeSentenceVn
            QuizExerciseType.TRANSLATION -> exercise.translationQuestion.ifEmpty { exercise.promptJp }
        }

        val optionsList = when (exercise.type) {
            QuizExerciseType.MULTIPLE_CHOICE -> exercise.options
            QuizExerciseType.FILL_IN_BLANK -> exercise.options
            QuizExerciseType.SENTENCE_BUILDER -> exercise.builderTokens
            QuizExerciseType.TRANSLATION -> exercise.options
        }

        return GrammarQuestion(
            id = exercise.id,
            grammarPoint = exercise.grammarPoint,
            question = questionText,
            options = optionsList,
            correctAnswerIndex = exercise.correctAnswerIndex,
            explanation = exercise.explanation,
            mistakeExplanation = exercise.mistakeExplanation,
            ruleSummary = exercise.ruleSummary,
            similarQuestion = exercise.similarExercise?.let { toGrammarQuestion(it) }
        )
    }

    /**
     * Tạo bài tập cho một điểm ngữ pháp bất kỳ từ kho 134 cấu trúc đã import
     */
    fun createExerciseForGrammarPoint(
        grammarTitle: String,
        structure: String,
        meaning: String,
        exampleJp: String,
        exampleVn: String
    ): QuizExercise {
        // Tự động phân chia thành bài tập điền khuyết hoặc trắc nghiệm
        val parts = exampleJp.split(" ")
        val blankQuestion = if (parts.size >= 2) {
            exampleJp.replaceFirst(parts.last(), "【 ＿＿＿ 】")
        } else {
            exampleJp
        }

        return QuizExercise(
            id = "custom_${System.currentTimeMillis()}",
            type = QuizExerciseType.FILL_IN_BLANK,
            grammarPoint = grammarTitle,
            instruction = "Chọn cấu trúc ngữ pháp thích hợp để hoàn thành câu:",
            promptJp = blankQuestion,
            promptVn = exampleVn,
            sentenceWithBlank = blankQuestion,
            blankMissingWord = structure,
            options = listOf(
                structure,
                "〜わけがない",
                "〜に反して",
                "〜に基づいて"
            ),
            correctAnswerIndex = 0,
            explanation = "【$grammarTitle】$meaning\nCấu trúc: $structure",
            mistakeExplanation = "Cần nắm vững cấu trúc $structure để diễn đạt ý nghĩa '$meaning'.",
            ruleSummary = "QUY LUẬT QUY NẠP: $structure → $meaning"
        )
    }
}
