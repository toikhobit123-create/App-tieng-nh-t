package com.example.data.repository

import android.content.Context
import com.example.data.model.GrammarExample
import com.example.data.model.GrammarLesson
import com.example.data.model.GrammarPoint
import java.io.InputStream

/**
 * Loads and parses JLPT N3 grammar lessons and grammar points from assets or resources.
 * Contains 27 lessons and 134 grammar points.
 */
object GrammarDataLoader {

    private var cachedLessons: List<GrammarLesson>? = null
    private var cachedAllGrammar: List<GrammarPoint>? = null

    fun getLessons(context: Context? = null): List<GrammarLesson> {
        cachedLessons?.let { return it }
        val lessons = loadLessons(context)
        cachedLessons = lessons
        cachedAllGrammar = lessons.flatMap { it.grammarList }
        return lessons
    }

    fun getAllGrammar(context: Context? = null): List<GrammarPoint> {
        cachedAllGrammar?.let { return it }
        getLessons(context)
        return cachedAllGrammar ?: emptyList()
    }

    private fun loadLessons(context: Context?): List<GrammarLesson> {
        val stream: InputStream? = try {
            context?.assets?.open("n3_grammar.json")
        } catch (_: Exception) {
            null
        } ?: try {
            GrammarDataLoader::class.java.classLoader?.getResourceAsStream("n3_grammar.json")
        } catch (_: Exception) {
            null
        } ?: try {
            GrammarDataLoader::class.java.classLoader?.getResourceAsStream("assets/n3_grammar.json")
        } catch (_: Exception) {
            null
        } ?: try {
            GrammarDataLoader::class.java.getResourceAsStream("/n3_grammar.json")
        } catch (_: Exception) {
            null
        }

        if (stream == null) {
            return emptyList()
        }

        val text = stream.bufferedReader().use { it.readText() }
        return parseGrammarJson(text)
    }

    fun parseGrammarJson(text: String): List<GrammarLesson> {
        val lessonBlocks = text.split(Regex("""\{\s*"lesson_id"\s*:\s*""")).drop(1)
        val lessons = mutableListOf<GrammarLesson>()
        val grammarItemPattern = Regex("""\{\s*"grammar"\s*:\s*"([^"]+)"\s*,\s*"meaning"\s*:\s*"([^"]+)"\s*\}""")
        val lidPattern = Regex("""^(\d+)""")
        val titlePattern = Regex(""""title"\s*:\s*"([^"]+)"""")

        for ((idx, block) in lessonBlocks.withIndex()) {
            val lidMatch = lidPattern.find(block)
            val titleMatch = titlePattern.find(block)
            val lessonId = lidMatch?.groupValues?.getOrNull(1)?.toIntOrNull() ?: (idx + 1)
            val title = titleMatch?.groupValues?.getOrNull(1) ?: "Bài $lessonId"

            val grammarMatches = grammarItemPattern.findAll(block)
            val grammarList = mutableListOf<GrammarPoint>()

            for ((gIdx, m) in grammarMatches.withIndex()) {
                val grammarTitle = m.groupValues[1]
                val meaning = m.groupValues[2]
                val cleanGrammar = grammarTitle.replace("〜", "").replace("。", "").trim()

                val pointId = "gp_${lessonId}_${gIdx + 1}"
                val examples = createExamplesForGrammar(grammarTitle, cleanGrammar, meaning, lessonId)
                val isKoto = grammarTitle.contains("ことにしている") || grammarTitle.contains("ことにしています")

                grammarList.add(
                    GrammarPoint(
                        id = if (isKoto) "np_01" else pointId,
                        title = if (isKoto) "〜ことにしています" else grammarTitle,
                        structure = if (isKoto) "V-ru / V-nai + ことにしている" else grammarTitle,
                        meaning = if (isKoto) "Biểu thị thói quen do chính bản thân tự quyết định và đang duy trì." else meaning,
                        examples = examples,
                        level = "N3",
                        questionRefId = if (isKoto) "grammar_0_koto" else null,
                        lessonId = lessonId,
                        lessonTitle = title
                    )
                )
            }
            lessons.add(GrammarLesson(lessonId, title, grammarList))
        }
        return lessons
    }

    private fun createExamplesForGrammar(
        grammar: String,
        cleanGrammar: String,
        meaning: String,
        lessonId: Int
    ): List<GrammarExample> {
        // Cung cấp ví dụ thực tế chuẩn JLPT N3 cho các cấu trúc đặc trưng
        return when {
            grammar.contains("ことにしている") -> listOf(
                GrammarExample(
                    jp = "健康のために、毎日野菜を食べることにしています。",
                    vn = "Vì sức khỏe, tôi quyết định duy trì thói quen ăn rau mỗi ngày."
                ),
                GrammarExample(
                    jp = "どんなに忙しくても、寝る前に日本語を15分勉強することにしています。",
                    vn = "Dù bận đến đâu, tôi cũng duy trì thói quen học tiếng Nhật 15 phút trước khi đi ngủ."
                )
            )
            grammar.contains("つまり") -> listOf(
                GrammarExample(
                    jp = "父の兄、つまり私のおじは医者をしています。",
                    vn = "Anh trai của bố tôi, tức là bác tôi, đang làm bác sĩ."
                )
            )
            grammar.contains("ということは") -> listOf(
                GrammarExample(
                    jp = "ご意見がないということは、賛成ということですね。",
                    vn = "Không có ý kiến gì, vậy tức là mọi người đều tán thành đúng không."
                )
            )
            grammar.contains("というのは") -> listOf(
                GrammarExample(
                    jp = "今度の旅行には行けません。というのは、急な仕事が入ったからです。",
                    vn = "Chuyến du lịch lần này tôi không đi được. Lý do là vì có công việc đột xuất."
                )
            )
            grammar.contains("というと") -> listOf(
                GrammarExample(
                    jp = "日本の春というと、やはり桜を思い出します。",
                    vn = "Nhắc đến mùa xuân của Nhật Bản, quả nhiên người ta nhớ ngay đến hoa anh đào."
                )
            )
            grammar.contains("ということだ") -> listOf(
                GrammarExample(
                    jp = "天気予報によると、明日は一日中雨が降るということです。",
                    vn = "Theo dự báo thời tiết, nghe nói ngày mai trời sẽ mưa cả ngày."
                )
            )
            grammar.contains("ば〜ほど") || grammar.contains("ほど") -> listOf(
                GrammarExample(
                    jp = "日本語は勉強すればするほど、面白くなってきます。",
                    vn = "Tiếng Nhật càng học thì càng thấy trở nên thú vị."
                )
            )
            grammar.contains("おかげで") -> listOf(
                GrammarExample(
                    jp = "先生のご指導のおかげで、JLPT N3に合格できました。",
                    vn = "Nhờ sự chỉ bảo tận tình của thầy giáo mà em đã thi đỗ JLPT N3."
                )
            )
            grammar.contains("せいで") -> listOf(
                GrammarExample(
                    jp = "バスが遅れたせいで、約束の時間に間に合いませんでした。",
                    vn = "Tại vì xe buýt đến muộn nên tôi đã không kịp giờ hẹn."
                )
            )
            grammar.contains("わけがない") -> listOf(
                GrammarExample(
                    jp = "あんなに真面目な田中さんが嘘をつくわけがありません。",
                    vn = "Người nghiêm túc như anh Tanaka không đời nào lại nói dối."
                )
            )
            grammar.contains("べきだ") -> listOf(
                GrammarExample(
                    jp = "約束したことは、最後まで必ず守るべきです。",
                    vn = "Những việc đã hứa thì chắc chắn phải giữ lời đến cùng."
                )
            )
            grammar.contains("ように") -> listOf(
                GrammarExample(
                    jp = "風邪を引かないように、手洗いうがいをしっかりしましょう。",
                    vn = "Để không bị cảm cúm, hãy nhớ rửa tay và súc họng cẩn thận."
                )
            )
            else -> listOf(
                GrammarExample(
                    jp = "JLPT N3の文法「$cleanGrammar」を正しく使って練習しましょう。",
                    vn = "Cấu trúc ngữ pháp N3「$cleanGrammar」: $meaning."
                )
            )
        }
    }
}
