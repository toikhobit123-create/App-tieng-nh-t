package com.example

import com.example.ui.state.NihongoViewModel
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertTrue
import org.junit.Before
import org.junit.Test

class NihongoViewModelTest {

    private lateinit var viewModel: NihongoViewModel

    @Before
    fun setUp() {
        viewModel = NihongoViewModel()
    }

    @Test
    fun testGrammarCorrectAnswer_updatesScoreAndCorrectState() {
        val initialScore = viewModel.uiState.value.score
        val correctIndex = viewModel.uiState.value.activeQuestion.correctAnswerIndex

        viewModel.selectGrammarOption(correctIndex)
        viewModel.submitGrammarAnswer()

        val state = viewModel.uiState.value
        assertTrue(state.isAnswerEvaluated)
        assertTrue(state.isAnswerCorrect)
        assertEquals(initialScore + 50, state.score)
    }

    @Test
    fun testGrammarWrongAnswer_andRetrySimilarQuestion() {
        val wrongIndex = 1 // Not the correct answer 0
        viewModel.selectGrammarOption(wrongIndex)
        viewModel.submitGrammarAnswer()

        val stateAfterSubmit = viewModel.uiState.value
        assertTrue(stateAfterSubmit.isAnswerEvaluated)
        assertFalse(stateAfterSubmit.isAnswerCorrect)

        // Retry similar question
        viewModel.retrySimilarQuestion()
        val stateAfterRetry = viewModel.uiState.value
        assertFalse(stateAfterRetry.isAnswerEvaluated)
        assertFalse(stateAfterRetry.isAnswerCorrect)
        assertTrue(stateAfterRetry.isShowingSimilarQuestion)
        assertNotNull(stateAfterRetry.activeQuestion)
    }

    @Test
    fun testSm2Algorithm_ratingAgain_resetsIntervalAndIncreasesLapses() {
        val initialProgress = com.example.data.model.SrsProgress(
            id = "test_card",
            type = com.example.data.model.SrsItemType.VOCABULARY,
            repetitions = 3,
            intervalDays = 6,
            easeFactor = 2.5,
            stage = com.example.data.model.SrsStage.REVIEW,
            lapses = 0
        )

        val updated = com.example.data.srs.Sm2Algorithm.calculateNextReview(
            initialProgress,
            com.example.data.model.SrsRating.AGAIN
        )

        assertEquals(0, updated.repetitions)
        assertEquals(1, updated.intervalDays)
        assertEquals(1, updated.lapses)
        assertEquals(com.example.data.model.SrsStage.LEARNING, updated.stage)
    }

    @Test
    fun testSm2Algorithm_ratingGoodAndEasy_progressesInterval() {
        var progress = com.example.data.model.SrsProgress(
            id = "test_2",
            type = com.example.data.model.SrsItemType.VOCABULARY
        )

        // First review Good -> interval 1, reps 1
        progress = com.example.data.srs.Sm2Algorithm.calculateNextReview(
            progress,
            com.example.data.model.SrsRating.GOOD
        )
        assertEquals(1, progress.repetitions)
        assertEquals(1, progress.intervalDays)

        // Second review Good -> interval 6, reps 2
        progress = com.example.data.srs.Sm2Algorithm.calculateNextReview(
            progress,
            com.example.data.model.SrsRating.GOOD
        )
        assertEquals(2, progress.repetitions)
        assertEquals(6, progress.intervalDays)

        // Third review Easy -> interval increases with EF bonus
        val previousInterval = progress.intervalDays
        progress = com.example.data.srs.Sm2Algorithm.calculateNextReview(
            progress,
            com.example.data.model.SrsRating.EASY
        )
        assertEquals(3, progress.repetitions)
        assertTrue(progress.intervalDays > previousInterval)
        assertTrue(progress.easeFactor >= 2.5)
    }

    @Test
    fun testSrsSession_cardFlippingAndRating() {
        viewModel.loadSrsSession()
        val initialDue = viewModel.uiState.value.srsDueCards.size
        assertTrue(initialDue > 0)

        // Initial front face
        assertFalse(viewModel.uiState.value.isSrsCardFlipped)

        // Flip card
        viewModel.flipSrsCard()
        assertTrue(viewModel.uiState.value.isSrsCardFlipped)

        // Rate card as Good
        val activePair = viewModel.uiState.value.srsDueCards.getOrNull(viewModel.uiState.value.currentSrsIndex)
        assertNotNull(activePair)
        viewModel.rateSrsCard(com.example.data.model.SrsRating.GOOD)

        // Verifies card flip resets for next card and score increases
        assertFalse(viewModel.uiState.value.isSrsCardFlipped)
        assertTrue(viewModel.uiState.value.score > 0)
    }

    @Test
    fun testPveCardBattle_matchWord_reducesBossHpAndAddsScore() {
        val initialBossHp = viewModel.uiState.value.bossHp
        val initialScore = viewModel.uiState.value.score
        val activeQ = viewModel.uiState.value.activePveQuestion
        val correctVocab = activeQ.options.first { it.kanji == activeQ.missingWord }

        viewModel.playPveCard(correctVocab)

        val state = viewModel.uiState.value
        assertEquals(initialBossHp - 40, state.bossHp)
        assertEquals(initialScore + 100, state.score)
        assertEquals(correctVocab.kanji, state.filledBlankWord)
    }

    @Test
    fun testPveCardBattle_wrongWord_reducesUserHp() {
        val initialUserHp = viewModel.uiState.value.userHp
        val activeQ = viewModel.uiState.value.activePveQuestion
        val wrongVocab = activeQ.options.first { it.kanji != activeQ.missingWord }

        viewModel.playPveCard(wrongVocab)

        val state = viewModel.uiState.value
        assertEquals(initialUserHp - 25, state.userHp)
        assertTrue(state.isUserHit)
    }

    @Test
    fun testAiApiKey_isConfigured() {
        // Kiểm tra cơ chế cấu hình và cập nhật API key an toàn qua AiService
        val initialKey = com.example.data.service.AiService.getApiKey()
        assertNotNull(initialKey)

        com.example.data.service.AiService.updateCustomApiKey("test_api_key_12345")
        assertEquals("test_api_key_12345", com.example.data.service.AiService.getApiKey())
        assertTrue(com.example.data.service.AiService.API_KEY.isNotBlank())

        // Đặt lại trạng thái
        com.example.data.service.AiService.updateCustomApiKey("")
    }

    @Test
    fun testStudyCategories_switchAndSelectGrammarFirst() {
        val state = viewModel.uiState.value
        // Verify default category is GRAMMAR (imported first)
        assertEquals(com.example.data.model.StudyCategory.GRAMMAR, state.selectedStudyCategory)

        // Switch to VOCABULARY
        viewModel.selectStudyCategory(com.example.data.model.StudyCategory.VOCABULARY)
        assertEquals(com.example.data.model.StudyCategory.VOCABULARY, viewModel.uiState.value.selectedStudyCategory)

        // Switch to KANJI
        viewModel.selectStudyCategory(com.example.data.model.StudyCategory.KANJI)
        assertEquals(com.example.data.model.StudyCategory.KANJI, viewModel.uiState.value.selectedStudyCategory)
    }

    @Test
    fun testImportedGrammar_np01_existsWithExactJsonContent() {
        val grammarPoints = viewModel.uiState.value.grammarPoints
        val np01 = grammarPoints.firstOrNull { it.id == "np_01" }

        assertNotNull(np01)
        assertEquals("〜ことにしています", np01!!.title)
        assertEquals("V-ru / V-nai + ことにしている", np01.structure)
        assertEquals("Biểu thị thói quen do chính bản thân tự quyết định và đang duy trì.", np01.meaning)
        assertTrue(np01.examples.isNotEmpty())
        assertEquals("健康のために、毎日野菜を食べることにしています。", np01.examples[0].jp)
        assertEquals("Vì sức khỏe, tôi quyết định duy trì thói quen ăn rau mỗi ngày.", np01.examples[0].vn)
    }

    @Test
    fun testStartQuizForImportedGrammar_navigatesToQuestion() {
        viewModel.startQuizForGrammar("np_01")
        val state = viewModel.uiState.value

        assertEquals(com.example.ui.state.Screen.INDUCTIVE_LEARNING, state.currentScreen)
        assertEquals("grammar_0_koto", state.activeQuestion.id)
        assertTrue(state.activeQuestion.grammarPoint.contains("〜ことにしています"))
    }

    @Test
    fun testN3Vocabulary_loads23LessonsAnd1138Items() {
        val state = viewModel.uiState.value
        assertEquals(23, state.vocabLessons.size)
        assertEquals(1138, state.vocabularyList.size)

        // Verify Lesson 1 first item
        val lesson1 = state.vocabLessons.first()
        assertEquals(1, lesson1.lessonId)
        assertEquals("Bài 1", lesson1.title)
        assertEquals(50, lesson1.vocabList.size)
        assertEquals("相手", lesson1.vocabList[0].kanji)
        assertEquals("あいて", lesson1.vocabList[0].hiragana)
        assertTrue(lesson1.vocabList[0].meaning.contains("Đối phương"))

        // Verify Lesson 23
        val lesson23 = state.vocabLessons.last()
        assertEquals(23, lesson23.lessonId)
        assertEquals("Bài 23", lesson23.title)
        assertEquals(38, lesson23.vocabList.size)
    }

    @Test
    fun testN3Vocabulary_lessonAndSearchFiltering() {
        viewModel.selectVocabLesson(2)
        assertEquals(2, viewModel.uiState.value.selectedVocabLessonId)

        viewModel.setVocabSearchQuery("幸運")
        assertEquals("幸運", viewModel.uiState.value.vocabSearchQuery)

        // Reset
        viewModel.selectVocabLesson(null)
        assertEquals(null, viewModel.uiState.value.selectedVocabLessonId)
        viewModel.setVocabSearchQuery("")
        assertEquals("", viewModel.uiState.value.vocabSearchQuery)
    }

    @Test
    fun testSentenceBuilder_selectAndRemoveChips_andSubmitCorrectly() {
        // Advance until a SENTENCE_BUILDER exercise is active
        var attempts = 0
        while (viewModel.uiState.value.activeExercise.type != com.example.data.model.QuizExerciseType.SENTENCE_BUILDER && attempts < 10) {
            viewModel.nextGrammarQuestion()
            attempts++
        }

        val ex = viewModel.uiState.value.activeExercise
        assertEquals(com.example.data.model.QuizExerciseType.SENTENCE_BUILDER, ex.type)
        assertTrue(viewModel.uiState.value.sentenceBuilderAvailableChips.isNotEmpty())

        // Select first chip
        val firstTargetChip = ex.correctTokenOrder[0]
        viewModel.selectSentenceBuilderChip(firstTargetChip)
        assertEquals(listOf(firstTargetChip), viewModel.uiState.value.sentenceBuilderSelectedChips)
        assertFalse(viewModel.uiState.value.sentenceBuilderAvailableChips.contains(firstTargetChip))

        // Remove that chip to test undo
        viewModel.removeSentenceBuilderChip(0)
        assertTrue(viewModel.uiState.value.sentenceBuilderSelectedChips.isEmpty())
        assertTrue(viewModel.uiState.value.sentenceBuilderAvailableChips.contains(firstTargetChip))

        // Build entire correct sentence
        ex.correctTokenOrder.forEach { chip ->
            viewModel.selectSentenceBuilderChip(chip)
        }
        assertEquals(ex.correctTokenOrder, viewModel.uiState.value.sentenceBuilderSelectedChips)

        // Submit
        val initialScore = viewModel.uiState.value.score
        viewModel.submitGrammarAnswer()
        assertTrue(viewModel.uiState.value.isAnswerEvaluated)
        assertTrue(viewModel.uiState.value.isAnswerCorrect)
        assertEquals(initialScore + 50, viewModel.uiState.value.score)
    }

    @Test
    fun testQuizEngine_containsAllFourExerciseTypes() {
        val exercises = viewModel.uiState.value.exerciseList
        assertTrue(exercises.isNotEmpty())

        val types = exercises.map { it.type }.toSet()
        assertTrue(types.contains(com.example.data.model.QuizExerciseType.MULTIPLE_CHOICE))
        assertTrue(types.contains(com.example.data.model.QuizExerciseType.FILL_IN_BLANK))
        assertTrue(types.contains(com.example.data.model.QuizExerciseType.SENTENCE_BUILDER))
        assertTrue(types.contains(com.example.data.model.QuizExerciseType.TRANSLATION))
    }

    @Test
    fun testAiMistakeAnalysis_triggeredOnWrongAnswer() {
        // Submit a wrong answer
        val wrongIndex = 99 // out of range / invalid index
        viewModel.selectGrammarOption(wrongIndex)
        viewModel.submitGrammarAnswer()

        val state = viewModel.uiState.value
        assertTrue(state.isAnswerEvaluated)
        assertFalse(state.isAnswerCorrect)
        // AI analysis is triggered in viewModelScope
        assertTrue(state.isAiMistakeLoading || state.aiMistakeExplanation != null)
    }
}
